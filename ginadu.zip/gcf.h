#ifndef GCF_H
#define GCF_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gcf.h
        Description: Main holder of library of headers of the framework.
***************************************************************************/
#include <base/gabaco.h>
#include <base/grect.h>
#include <base/gpair.h>
#include <base/gptrpair.h>
#include <gstring/gstring.h>
#include <gstring/gstringlist.h>
#include <containers/galignedlist.h>
#include <containers/galignedptrlist.h>
#include <containers/garray.h>
#include <containers/ghashmap.h>
#include <containers/glinkedlist.h>
#include <containers/gtree.h>
#include <containers/galignedptrtable.h>
#include <containers/gbuffer.h>
#include <gvariant/gvariant.h>
#include <gvariant/gvariantlist.h>
#include <io/gfile.h>
#include <utils/gscoder.h>
#include <utils/glexer.h>
#include <utils/gurl.h>
#include <utils/gxmlparser.h>
#include <utils/glattyscript.h>
#include <utils/gvardimmachine.h>
#include <utils/gmandelmachine.h>
#include <gmath/gmath.h>
#include <gmath/galgorithm.h>
#include <gmath/gvector2.h>
#include <gmath/gmatrix2.h>
#include <gmath/gpatselmachine.h>
#include <concurrency/gthread.h>
#include <concurrency/gmutex.h>
#include <system/glibrary.h>
#include <system/gdatetime.h>
#include <timers/gvirtualtimer.h>
#endif // GCF_H
