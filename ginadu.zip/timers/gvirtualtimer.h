#ifndef GVIRTUALTIMER_H
#define GVIRTUALTIMER_H
#include <gstring/gstring.h>
#include "gvirtualtimercallback.h"
namespace gcf
{
class SHARED_GCF gVirtualTimer
{
public:
    gVirtualTimer();
    gVirtualTimer(gVirtualTimerCallback *func);
    gVirtualTimer(const gVirtualTimer &other);
    ~gVirtualTimer();

    gVirtualTimer &operator = (const gVirtualTimer &other);

    void setInterval(gu32 msval);
    void setVirtualTimerSpeed(float sp);
    void setPeriodic(bool set);
    void setID(gs32 nid);
    void setIdentifier(const gString &sid);
    void setCallbackFunction(gVirtualTimerCallback *func);
    void setUserData(void *ud);

    void start();
    void stop();

    gu32 getVirtualTime();
    gu32 getRealTime() const;
    void poll();

    gu32 interval() const;
    gf32 virtualTimeSpeed() const;
    gs32 id() const;
    const gString &identifier() const;
    gVirtualTimerCallback *callbackFunction();
    void *userdata();

    bool isPeriodic() const;
    bool isRunning() const;

    gu32 elapsedVirtualTime() const;
    void timeOut();

    void copy(const gVirtualTimer &other);

protected:
    gf32 m_virtualtimespeed;
    gu32 m_realtimestart;
    gu32 m_timerstart;
    gu32 m_interval;
    bool m_periodic;
    bool m_running;
    gs32 m_id;
    gString m_sid;
    gVirtualTimerCallback *m_func;
    void *m_userdata;

};
}


#endif // GVIRTUALTIMER_H
