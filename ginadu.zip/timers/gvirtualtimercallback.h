#ifndef GVIRTUALTIMERCALLBACK_H
#define GVIRTUALTIMERCALLBACK_H
#include <base/gcommon.h>

namespace gcf
{
class gVirtualTimer;
class gVirtualTimerCallback
{
public:
    gVirtualTimerCallback()
    {

    }
    virtual ~gVirtualTimerCallback()
    {

    }
    virtual void timeOut(gVirtualTimer *vt) = 0;


};
}

#endif // GVIRTUALTIMERCALLBACK_H
