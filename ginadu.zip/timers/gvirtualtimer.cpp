#include "gvirtualtimer.h"
#ifdef WIN32
#include <windows.h>
#endif
#ifdef __gnu_linux__
#include <sys/time.h>
#include <stdio.h>
#endif
using namespace gcf;

gVirtualTimer::gVirtualTimer():
    m_virtualtimespeed(1.0),
    m_realtimestart(0),
    m_timerstart(0),
    m_interval(0),
    m_periodic(true),
    m_running(false),
    m_id(-1),
    m_func(0),
    m_userdata(0)
{
    m_timerstart = getRealTime();
}
gVirtualTimer::gVirtualTimer(gVirtualTimerCallback *func):
    m_virtualtimespeed(1.0),
    m_realtimestart(0),
    m_timerstart(0),
    m_interval(0),
    m_periodic(true),
    m_running(false),
    m_id(-1),
    m_func(func),
    m_userdata(0)
{
    m_timerstart = getRealTime();
}
gVirtualTimer::gVirtualTimer(const gVirtualTimer &other)
{
    copy(other);
}
gVirtualTimer::~gVirtualTimer()
{

}
gVirtualTimer &gVirtualTimer::operator =(const gVirtualTimer &other)
{
    copy(other);
    return *this;
}
void gVirtualTimer::setInterval(gu32 msval)
{
    m_interval = msval;
}
void gVirtualTimer::setVirtualTimerSpeed(float sp)
{
    m_virtualtimespeed = sp;
}
void gVirtualTimer::setPeriodic(bool set)
{
    m_periodic = set;
}
void gVirtualTimer::setID(gs32 nid)
{
    m_id = nid;
}
void gVirtualTimer::setIdentifier(const gString &sid)
{
    m_sid = sid;
}
void gVirtualTimer::setCallbackFunction(gVirtualTimerCallback *func)
{
    m_func = func;
}
void gVirtualTimer::setUserData(void *ud)
{
    m_userdata = ud;
}

void gVirtualTimer::start()
{
    m_realtimestart = getRealTime();
    m_running = true;
}
void gVirtualTimer::stop()
{
    m_realtimestart = 0;
    m_running = false;
}
gu32 gVirtualTimer::getVirtualTime()
{
    if(m_running == false)
    {
        return 0;
    }
    return gu32(getRealTime() - m_realtimestart) * m_virtualtimespeed;
}
gu32 gVirtualTimer::getRealTime() const
{
#ifdef __gnu_linux__
    timeval tv;
    gettimeofday(&tv, 0);
    return (gu32)(tv.tv_sec * 1000) + (tv.tv_usec / 1000);
#endif
#ifdef WIN32
    return GetTickCount();
#endif
}
void gVirtualTimer::poll()
{
    if(m_running == false)
    {
        return;
    }
    if(m_interval <= getVirtualTime())
    {
        timeOut();
        if(m_periodic)
        {

            m_realtimestart = getRealTime();
        }
        else
        {
            stop();
        }
    }
}
gu32 gVirtualTimer::interval() const
{
    return m_interval;
}
gf32 gVirtualTimer::virtualTimeSpeed() const
{
    return m_virtualtimespeed;
}
gs32 gVirtualTimer::id() const
{
    return m_id;
}
const gString &gVirtualTimer::identifier() const
{
    return m_sid;
}
gVirtualTimerCallback *gVirtualTimer::callbackFunction()
{
    return m_func;
}
void *gVirtualTimer::userdata()
{
    return m_userdata;
}

bool gVirtualTimer::isPeriodic() const
{
    return m_periodic;
}
bool gVirtualTimer::isRunning() const
{
    return m_running;
}
gu32 gVirtualTimer::elapsedVirtualTime() const
{
    return gu32(getRealTime() - m_timerstart) * m_virtualtimespeed;
}
void gVirtualTimer::timeOut()
{
    if(m_func)
    {
        m_func->timeOut(this);
    }
}
void gVirtualTimer::copy(const gVirtualTimer &other)
{
    m_virtualtimespeed = other.m_virtualtimespeed;
    m_realtimestart = other.m_realtimestart;
    m_timerstart = other.m_timerstart;
    m_interval = other.m_interval;
    m_periodic = other.m_periodic;
    m_running = other.m_running;
    m_id = other.m_id;
    m_sid = other.m_sid;
    m_func = other.m_func;
    m_userdata = other.m_userdata;
}
