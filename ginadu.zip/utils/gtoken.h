#ifndef GTOKEN_H
#define GTOKEN_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gtoken.h
        Description: Implementation of gToken class.
****************************************************************************/
#include <gstring/gstring.h>

namespace gcf
{
/*! \brief The class gToken is the representation of token string while parsing
           a string by gLexer class.
*/
class gToken
{
public:
    gToken():
        m_id1(-1),
        m_id2(-1)
    {

    }
    ~gToken()
    {

    }
    void clear()
    {
        m_string.clear();
        m_id1 = -1;
        m_id2 = -1;
    }

    void setString(const gString &str)
    {
        m_string = str;
    }
    const gString &string() const
    {
        return m_string;
    }
    void setID1(gs32 nid1)
    {
        m_id1 = nid1;
    }
    void setID2(gs32 nid2)
    {
        m_id2 = nid2;
    }
    gs32 id1() const
    {
        return m_id1;
    }
    gs32 id2() const
    {
        return m_id2;
    }
protected:
    gString m_string;
    gs32 m_id1;
    gs32 m_id2;
};
}

#endif // GTOKEN_H
