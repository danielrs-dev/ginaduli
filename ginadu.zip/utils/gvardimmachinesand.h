#ifndef GVARDIMMACHINESAND_H
#define GVARDIMMACHINESAND_H
#include <containers/galignedptrlist.h>
#include "gvardimoperation.h"
namespace gcf
{
typedef gAlignedPtrList<gVardimOperation, gDAllocator<gVardimOperation> > gVardimOperations;
typedef gAlignedPtrList<gVardimVariable,gDAllocator<gVardimVariable> > gVardimVariables;
struct gVardimMachineSand
{
    gVardimMachineSand()
    {

    }
    ~gVardimMachineSand()
    {

    }
    gVardimVariable *search(const gString &sid, gu32 *idx = 0)
    {
        gVardimVariable *v;
        gu32 i;
        for(i = 0; i < variables.size(); i++)
        {
            v = variables.value(i);
            if(v)
            {
                if(v->identifier() == sid)
                {
                    if(idx)
                    {
                        *idx = i;
                    }
                    return v;
                }
            }
        }
        return 0;
    }


    gVardimOperations operations;
    gVardimVariables variables;
    gVariant dummy;
};
}
#endif // GVARDIMMACHINESAND_H
