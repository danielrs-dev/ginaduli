#ifndef GLATTYSCRIPT_H
#define GLATTYSCRIPT_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glattyscript.h
        Description: Implementation of gLattyScript class.
****************************************************************************/
#include "glattynode.h"
#include "glattydefinition.h"
#include "glattyerror.h"
#include <containers/gtree.h>
#include "glexer.h"
namespace gcf
{
enum GLATTY_TOKENEXT
{
    GTOKEN_LATTYASSIGNTO = 138,
    GTOKEN_LATTYASSIGN = 139

};

typedef gTree<gLattyNode,gDAllocator<gLattyNode> > gLattyTree;
typedef gLinkedList<gLattyError,gDAllocator<gLattyError> > gLattyErrorList;
typedef gLinkedList<gLattyDefinition,gDAllocator<gLattyDefinition> > gLattyDefinitionList;
class SHARED_GCF gLattyScript
{
public:
    gLattyScript();
    ~gLattyScript();

    bool openScript(const gString &filename);
    void setScript(const gString &script);

    //Errors
    bool hasErrors() const;
    void errorBegin();
    gLattyError *error();
    void errorNext();

    void parse(bool singleline = false);
    //Walking through the parsed script
    gLattyNode *walk();
    gLattyNode *walkNode();
    void clear();
    void clearDefs();
    //Handling definitions
    gLattyDefinition *addDefinition(const gString &sident,
                                    gs32 nid,
                                    gs32 ntype);
    gLattyDefinition *definition();
    gLattyDefinition *definition(const gString &ident);
    void firstDefinition();
    void nextDefinition();
    bool hasDefinitions() const;
    //Handling the internal parse tree
    void setMaster();
    void setChild();
    void setFather();
    gLattyNode *node();
    gLattyNode *childNode();
    void firstChild();
    void nextChild();
    void lastChild();
    //Handling tree levels
    void addLevel(const gString &sid);
    void addLevel(gs32 nid);
    bool inLevel(const gString &sid);
    bool inLevel(gs32 nid);
private:
    void writeError(const gString &smsg, const gString &add = gString());
    void getToken();
    gLattyNode *addNode(const gString &sid, gLattyNode *nparent, gs32 nid);
    gLattyNode *addNodeWithDef(const gString &sid, gLattyNode *nparent = 0);
    gLattyNode *addParamWithDef(gLattyNode *nnode, const gString &sident, gs32 ntype);
    void setMemberWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype);
    void setPropertyWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype);
    void setAssignToWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype);
    void setAssignWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype);
    gLattyNode *createNode(const gString &ident, gLattyNode *nparent = 0);
    void parseMain(bool singleline);
    gs32 parseCodeBlock(gLattyNode *nparent);
    gString parseString();
    void parseComment();
    gs32 parseParameters(gLattyNode *nnode);
    void parseCommand(gLattyNode *nparent, bool singleline = false);
protected:
    gLattyTree m_tree;
    gLexer m_lexer;
    gLattyErrorList m_errors;
    gLattyDefinitionList m_definitions;
    bool m_done;
};
}
#endif // GLATTYSCRIPT_H
