#ifndef GXMLNODE_H
#define GXMLNODE_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gxmlnode.h
        Description: Implementation of gXMLNode class.
****************************************************************************/
#include "gxmlattribute.h"
#include <containers/glinkedlist.h>
namespace gcf
{
enum GXMLNTYPES
{
    GXMLNT_UNASSIGNED,
    GXMLNT_NESTED,
    GXMLNT_NESTED_IGNORE,
    GXMLNT_SINGLE,
    GXMLNT_DATA,
    GXMLNT_MAIN
};

class SHARED_GCF gXMLNode
{
public:
    gXMLNode();
    ~gXMLNode();

    void setName(const gString &vname);
    void setID(gs32 nid);
    void setType(gs32 ntype);
    void setClosingTag(bool set);
    void setLine(gs32 nline);
    void setColumn(gs32 ncolumn);

    const gString &name() const;
    gs32 id() const;
    gs32 type() const;
    gs32 line() const;
    gs32 column() const;
    bool closingTag() const;

    gXMLAttribute *addAttribute(const gString &vname,
                                const gString &vvalue,
                                gs32 mcolumn,
                                gs32 mline);
    gXMLAttribute *attribute();
    gXMLAttribute *attribute(const gString &vname);
    bool hasAttribute(const gString &name);
    void firstAttribute();
    void lastAttribute();
    void nextAttribute();
    bool hasAttributes();
protected:
    gs32 m_id;
    gString m_name;
    gLinkedList<gXMLAttribute,gDAllocator<gXMLAttribute> > m_attributes;
    gu32 m_type;
    bool m_closingtag;
    gs32 m_line;
    gs32 m_column;
};
}
#endif // GXMLNODE_H
