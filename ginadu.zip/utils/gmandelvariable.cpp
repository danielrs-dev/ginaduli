#include "gmandelvariable.h"

using namespace gcf;

gMandelVariable::gMandelVariable()
{

}
gMandelVariable::~gMandelVariable()
{

}
void gMandelVariable::setIdentifier(const gString &ident)
{
    m_identifier = ident;
}
void gMandelVariable::setValue(const gVariant &val)
{
    m_value = val;
}
const gString &gMandelVariable::identifier() const
{
    return m_identifier;
}
const gVariant &gMandelVariable::value() const
{
    return m_value;
}
