#ifndef GLEXER_H
#define GLEXER_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glexer.h
        Description: Implementation of gLexer class.
****************************************************************************/
#include "gtoken.h"
#include "gtokens.h"

namespace gcf
{
/*! \brief The class gLexer is an object to parse strings and split it into
           tokens. Each token is identified by an integer ID  when found.
           File gtokens.h shows all characters and symbols the lexer identifies
           and separtes on the process of parsing.

           By defualt gLexer sperates string identifiers that follows many
           programming languages. Also it separates numeric values.
*/
class SHARED_GCF gLexer
{
public:
    /// Constructor
    gLexer();
    /// Destructor
    ~gLexer();
    void clear();
    /*! \brief Opens a text file and load it to the internal script data.
        \param filename: The name of the file to open.
        \return true if file could be loaded.
    */
    bool openScriptFile(const gString &filename);
    /*! \brief: Sets the lexer script given a string.
        \param sscript: String of script.
    */
    void setScript(const gString &sscript);
    /*! \brief Sets the current position of the parsing process of the lexer.
        \param nposition: New position in script.
    */
    void setPosition(gu32 nposition);
    /*! \brief Gets the script buffer on a position.
        \return Buffer string of script.
    */
    char *scriptPosition(gu32 nposition);
    void setTokenID1(gs32 nid);
    void setTokenID2(gs32 nid);
    void setTokenString(const gString &str);
    /*! \brief Parser function of the gLexer class. It follows the script
               until reaching the end of it. While walking to script it registers
               every found token into the gToken internal class.
               This function does not parse everything at once, but it does
               by calls. Each call means finding a new token and so on.
     */
    void getToken();
    /// Version of getToken that get negative numbers.
    void getToken(bool negvalues);
    /// Gets the current token found by getToken.
    const gToken &token() const;
    /// Gets the script string.
    const gString &script() const;
    /// Gets the current position of the parsing process.
    gu32 position() const;
    /// Gets the current line at the current positon.
    gu32 line() const;
    /// Gets the current column at the current position.
    gu32 column() const;
    /// Returns the size of the script string
    gu32 scriptSize() const;
    /// Sets position to 0
    void reset();
    /// Gets the current character on the current positon.
    char currentChar();
    /// Gets the next character and increases the position by 1.
    char nextChar();
    /// Gets the current token ID1
    gu32 tokenID1() const;
    /// Gets the current token ID2
    gu32 tokenID2() const;
    /// Gets the current token string
    const gString &tokenString() const;
    /*! \brief Sweeps the script from position storing every character
               found in the process until reach the stop charater.
        \param scharacter: Stop character.
        \return String found while sweeping.
    */
    gString sweep(char scharacter);
    gString sweep(const char *cst, gu32 nsize, bool skipsc);
    /*! \brief Takes a leap and bypasses every character increasing the
               position of the script registing nothing until finding
               the stop character.
        \param  scharacter: Stop character.
    */
    void bypass(char scharacter);
    void stepBack(bool token = true);
private:
    char getChar();
    char isAlpha(char ch);
    char isNumber(char ch);
    bool isHex(char ch); 
    char lastChar();
protected:
    /// Script data
    gString m_script;
    /// Parser position
    gu32 m_position;
    /// Current line position
    gu32 m_line;
    /// Current column position
    gu32 m_column;
    /// Token
    gToken m_token;
};
}

#endif // GLEXER_H
