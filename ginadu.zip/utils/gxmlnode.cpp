#include "gxmlnode.h"

using namespace gcf;

gXMLNode::gXMLNode():
    m_id(-1),
    m_type(GXMLNT_UNASSIGNED),
    m_closingtag(false)
{

}
gXMLNode::~gXMLNode()
{

}

void gXMLNode::setName(const gString &vname)
{
    m_name = vname;
}
void gXMLNode::setID(gs32 nid)
{
    m_id = nid;
}
void gXMLNode::setType(gs32 ntype)
{
    m_type = ntype;
}
void gXMLNode::setClosingTag(bool set)
{
    m_closingtag = set;
}
const gString &gXMLNode::name() const
{
    return m_name;
}
gs32 gXMLNode::id() const
{
    return m_id;
}
gs32 gXMLNode::type() const
{
    return m_type;
}
bool gXMLNode::closingTag() const
{
    return m_closingtag;
}
void gXMLNode::setLine(gs32 nline)
{
    m_line = nline;
}
void gXMLNode::setColumn(gs32 ncolumn)
{
    m_column = ncolumn;
}
gs32 gXMLNode::line() const
{
    return m_line;
}
gs32 gXMLNode::column() const
{
    return m_column;
}
gXMLAttribute *gXMLNode::addAttribute(const gString &vname,
                                      const gString &vvalue,
                                      gs32 mcolumn,
                                      gs32 mline)
{
    gXMLAttribute *attr = new gXMLAttribute();
    attr->setName(vname);
    attr->setValue(vvalue);
    attr->setColumn(mcolumn);
    attr->setLine(mline);
    m_attributes.append(attr);
    return attr;
}
gXMLAttribute *gXMLNode::attribute()
{
    return m_attributes.value();
}
gXMLAttribute *gXMLNode::attribute(const gString &vname)
{
    gXMLAttribute *attr;
    m_attributes.setFirst();
    while(m_attributes.node())
    {
        attr = m_attributes.value();
        if(attr->name() == vname)
        {
            return attr;
        }
        m_attributes.next();
    }
    return 0;
}
bool gXMLNode::hasAttributes()
{
    return m_attributes.isEmpty() == false;
}

bool gXMLNode::hasAttribute(const gString &name)
{
    gXMLAttribute *attr;
    attr = attribute(name);

    return (attr != 0);
}
void gXMLNode::firstAttribute()
{
    m_attributes.setFirst();
}
void gXMLNode::lastAttribute()
{
    m_attributes.setLast();
}
void gXMLNode::nextAttribute()
{
    m_attributes.next();
}
