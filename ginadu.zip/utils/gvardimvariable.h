
#ifndef GVARDIMVARIABLE_H
#define GVARDIMVARIABLE_H
#include <gvariant/gvariant.h>

namespace gcf
{
class gVardimVariable
{
public:
    gVardimVariable();
    ~gVardimVariable();
    void setIdentifier(const gString &id);
    const gString &identifier() const;
    void setValue(const gVariant &val);
    const gVariant &value() const;
protected:
    gString m_id;
    gVariant m_value;
};
}
#endif // GVARDIMVARIABLE_H
