#ifndef GLATTYERROR_H
#define GLATTYERROR_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glattyerror.h
        Description: Implementation of gLattyError class.
****************************************************************************/

#include <gstring/gstring.h>

namespace gcf
{
class gLattyError
{
public:
    gLattyError():
        m_column(0),
        m_line(0)
    {

    }
    ~gLattyError()
    {

    }
    void setMsg(const gString &smsg)
    {
        m_msg = smsg;
    }

    void setColumn(gs32 ncolumn)
    {
        m_column = ncolumn;
    }
    void setLine(gs32 nline)
    {
        m_line = nline;
    }
    const gString &msg() const
    {
        return m_msg;
    }
    gs32 column() const
    {
        return m_column;
    }
    gs32 line() const
    {
        return m_line;
    }
protected:
    gString m_msg;
    gu32 m_column;
    gu32 m_line;
};
}
#endif // GLATTYERROR_H
