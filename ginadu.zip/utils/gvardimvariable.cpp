#include "gvardimvariable.h"

using namespace gcf;

gVardimVariable::gVardimVariable()
{

}
gVardimVariable::~gVardimVariable()
{

}
void gVardimVariable::setIdentifier(const gString &id)
{
    m_id = id;
}
const gString &gVardimVariable::identifier() const
{
    return m_id;
}
void gVardimVariable::setValue(const gVariant &val)
{
    m_value = val;
}
const gVariant &gVardimVariable::value() const
{
    return m_value;
}
