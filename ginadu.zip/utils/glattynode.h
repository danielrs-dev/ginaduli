#ifndef GLATTYNODE_H
#define GLATTYNODE_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glattynode.h
        Description: Implementation of gLattyNode class.
****************************************************************************/
#include "glattyparam.h"
#include <containers/galignedptrlist.h>
#include <containers/glinkedlist.h>
namespace gcf
{

class SHARED_GCF gLattyNode
{
public:
    gLattyNode();
    gLattyNode(const gString &sident,
               gLattyNode *mparent,
               gs32 nid,
               gs32 ntype = GLATTYN_UNSET);
    ~gLattyNode();

    gLattyNode *addParam(const gString &sident,
                         gs32 nid,
                         gs32 ntype);
    void firstParam();
    void lastParam();
    void nextParam();
    gLattyNode *param();
    gLattyNode *param(const gString &sident);
    gLattyNode *param(gs32 nid);

    bool hasParameters() const;

    void setMember(const gString &sid, gs32 nid, gs32 ntype);
    void setProperty(const gString &sid, gs32 nid, gs32 ntype);
    void setAssignTo(const gString &sid, gs32 nid, gs32 ntype);
    void setAssign(const gString &sid, gs32 nid, gs32 ntype);
    void setMalden(gLattyNode *mnode);
    void setIdentifier(const gString &sident);
    void setID(gs32 nid);
    void setType(gs32 ntype);

    const gString &identifier() const;
    gs32 id() const;
    gs32 type() const;
    gLattyNode *malden();
    gLattyNode *member();
    gLattyNode *property();
    gLattyNode *assignTo();
    gLattyNode *assign();
public:
    typedef gLinkedList<gLattyNode,gDAllocator<gLattyNode> > gLattyNodeList;

protected:
    gString m_ident;
    gs32 m_id;
    gs32 m_type;
    gLattyNodeList m_params;
    gLattyNode *m_member;
    gLattyNode *m_property;
    gLattyNode *m_assignto;
    gLattyNode *m_assign;
    gLattyNode *m_parent;
    gLattyNode *m_malden;

};
}
#endif // GLATTYNODE_H
