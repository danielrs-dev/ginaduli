#include "gscoder.h"
#include <cstdlib>
#include <ctime>

using namespace gcf;


gSCoder::gSCoder():
    m_table(0),
    m_width(0),
    m_height(0)
{

}
gSCoder::~gSCoder()
{
    clear();
}
bool gSCoder::alloc(gu32 nwidth, gu32 nheight)
{
    gu32 x;
    m_table = static_cast<gu16 **>(malloc(nwidth * sizeof(gu16 *)));

    for(x = 0; x < nwidth; x++)
    {
        m_table[x] = static_cast<gu16 *>(malloc(nheight * sizeof(gu16)));
    }
    m_width = nwidth;
    m_height = nheight;
    return m_table != 0;
}
void gSCoder::clear()
{
    gu32 x;
    if(m_table == 0)
    {
        return;
    }
    for(x = 0; x < m_width; x++)
    {
        free(m_table[x]);
    }
    free(m_table);
    m_width = 0;
    m_height = 0;
    m_table = 0;
}
bool gSCoder::isEmpty() const
{
    return (m_table == 0);
}
gs32 gSCoder::defaultSetup(bool brandom, gs32 randomSeed)
{
    gu32 x,y;
    gs32 seed;
    gu16 val;
    gs32 inc = 0x00FF;

    alloc(256,256);

    if(brandom)
    {
        if(randomSeed > 0)
        {
            seed = randomSeed;
            val = randomSeed;
        }
        else
        {
            srand(time(0));
            seed = rand();
            GDRAND_RANGE(seed,0,65535,RAND_MAX);
            val = seed;
        }
    }
    for(x = 0; x < m_width; x++)
    {
        for(y = 0; y < m_height; y++)
        {
            m_table[x][y] =  val;
            if(brandom)
            {
                val+=inc;
            }
            else
            {
                val++;
            }
        }
    }
    return seed;
}

void gSCoder::setKey(const gString &skey)
{
    m_key = skey;
}
const gString &gSCoder::key() const
{
    return m_key;
}
void gSCoder::setValue(gu16 nvalue, gu32 nx, gu32 ny)
{
    m_table[nx][ny] = nvalue;
}
gu16 gSCoder::value(gu32 nx, gu32 ny) const
{
    return m_table[nx][ny];
}
//Private ones
gString gSCoder::uint16ToHex(gu16 val) const
{
    gString sret;
    gu32 i;
    char buff[5];

    sprintf(buff,"%4x",val);
    buff[4] = 0;
    for(i = 0; i < 4; i++)
    {
        if(buff[i] == ' ')
        {
            buff[i] = '0';
        }
    }
    sret.setString(buff,4);
    sret.setShared(true);
    return sret;
}
gAlignedList<gu16> gSCoder::fromHexToUint16Array(const gString &str) const
{
    gu32 count = str.size();
    gAlignedList<gu16> ret;
    const char *sbuff = str.asciiData();
    char buffer[5];
    gu32 i,j;
    gu16 val;
    count = count * 0.25;

    ret.alloc(count);
    ret.setUsed(count);
    for(i = 0, j = 0; i < count; i++, j += 4)
    {
        memcpy(buffer,&sbuff[j],4);
        buffer[4] = 0;
        sscanf(buffer,"%4x",&val);
        ret.setValue(val,i);
    }
    ret.setShared(true);
    return ret;
}
gString gSCoder::encode(const gString &src)
{
    const gu8 *bkey = (const gu8 *)m_key.asciiData();
    const gu8 *bsrc = (const gu8 *)src.asciiData();
    gu32 i,j,nsrc,nkey;
    gString ret,hex;

    nsrc = src.size();
    nkey = m_key.size();

    j = 0;
    for(i = 0; i < nsrc; i++)
    {
        if(j == nkey)
        {
            j = 0;
        }
        hex = uint16ToHex(m_table[bsrc[i]][bkey[j]]);
        ret += hex;
        j++;
    }
    ret.setShared(true);
    return ret;
}
gString gSCoder::decode(const gString &encoded)
{
    gString ret;
    char *bret;
    gAlignedList<gu16> indexes;
    gu32 nkey = m_key.size();
    gu8 *bkey = (gu8 *)m_key.asciiData();
    gu32 i = 0,j = 0,k = 0,klast = 0;
    gu16 *idx;
    gu32 idxcount;

    indexes = fromHexToUint16Array(encoded);
    idx = indexes.data();
    idxcount = indexes.used();

    ret.alloc(idxcount,GSF_ASCII);
    bret = ret.asciiData();

    while(i < idxcount)
    {
        if(j == m_width)
        {
            if(klast == k)
            {
                return gString();
            }
            j = 0;
        }
        if(k == nkey)
        {
            k = 0;
        }
        klast = k;
        if(idx[i] == m_table[j][bkey[k]])
        {
            bret[i] = j;
            i++;
            k++;
            j = 0;
        }
        else
        {
            j++;
        }

    }
    ret.setShared(true);
    return ret;
}
gu32 gSCoder::width() const
{
    return m_width;
}
gu32 gSCoder::height() const
{
    return m_height;
}
