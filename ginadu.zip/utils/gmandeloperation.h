#ifndef GMANDELOPERATION_H
#define GMANDELOPERATION_H
#include "gmandelvariable.h"

namespace gcf
{
enum GMANDEL_VALUE_OPS
{
    GMANDELOP_EQUAL,
    GMANDELOP_NOTEQUAL,
    GMANDELOP_LESS,
    GMANDELOP_GREAT,
    GMANDELOP_LESSOREQUAL,
    GMANDELOP_GREATOREQUAL,
    GMANDELOP_NOTSET
};
enum GMANDEL_STRINGA_OPS
{
    GMANDELSAOP_EQUAL,
    GMANDELSAOP_NOTEQUAL
};
enum GMANDEL_STRINGB_OPS
{
    GMANDELSBOP_INSTRING,
    GMANDELSBOP_OUTSTRING
};

enum GMANDEL_OPMODES
{
    GMANDELMOD_VALUES,
    GMANDELMOD_STRINGA,
    GMANDELMOD_STRINGB,
    GMANDELMOD_DATES
};

class SHARED_GCF gMandelOperation
{
public:
    gMandelOperation();
    virtual ~gMandelOperation();

    void setVariable1(gMandelVariable *var1);
    void setVariable2(gMandelVariable *var2);
    void setOperation(gs32 oper);
    void setMode(gs32 nmode);
    void setResult(bool res);

    gMandelVariable *variable1();
    gMandelVariable *variable2();
    gs32 operation() const;
    gs32 mode() const;
    bool result() const;

    void exec();
private:
    void execValues();
    void execStringA();
    void execStringB();
    void execDates();
protected:
    gMandelVariable *m_var1;
    gMandelVariable *m_var2;
    bool m_result;
    gs32 m_op;
    gs32 m_mode;
};
}

#endif // GMANDELOPERATION_H
