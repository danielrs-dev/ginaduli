#ifndef GCANDELOPERATION_H
#define GCANDELOPERATION_H
#include "gstring/gstring.h"
#include "gvariant/gvariant.h"
#include "gmath/gmathoperations.h"
#include "base/gpair.h"
namespace gcf
{


class SHARED_GCF gCandelOperation
{
public:
    gCandelOperation();
    ~gCandelOperation();

    void setOperation(gs32 op);
    void setValue1(const gString &var,const gVariant &val1);
    void setValue2(const gString &var,const gVariant &val2);
    void setLevel(gs32 nlevel);
    gs32 operation() const;
    gs32 level() const;
    const gVariant &value1() const;
    const gVariant &value2() const;
    const gString &var1() const;
    const gString &var2() const;

protected:
    gs32 m_operation;
    gs32 m_level;
    gPair<gString,gVariant> m_value1;
    gPair<gString,gVariant> m_value2;
};
}
#endif // GCANDELVALUE_H
