#include "glattynode.h"

using namespace gcf;


gLattyNode::gLattyNode():
    m_id(-1),
    m_type(GLATTYN_UNSET),
    m_member(0),
    m_property(0),
    m_assignto(0),
    m_assign(0),
    m_parent(0),
    m_malden(0)
{

}
gLattyNode::gLattyNode(const gString &sident, gLattyNode *mparent, gs32 nid, gs32 ntype):
    m_ident(sident),
    m_id(nid),
    m_type(ntype),
    m_member(0),
    m_property(0),
    m_assignto(0),
    m_assign(0),
    m_parent(mparent),
    m_malden(0)
{

}
gLattyNode::~gLattyNode()
{
    if(m_member)
    {
        delete m_member;
    }
    if(m_property)
    {
        delete m_property;
    }
    if(m_assignto)
    {
        delete m_assignto;
    }
    if(m_assign)
    {
        delete m_assign;
    }
}

gLattyNode *gLattyNode::addParam(const gString &sident, gs32 nid, gs32 ntype)
{
    gLattyNode *nparam = new gLattyNode(sident,0,nid,ntype);
    m_params.append(nparam);
    return nparam;
}
void gLattyNode::firstParam()
{
    m_params.setFirst();
}
void gLattyNode::lastParam()
{
    m_params.setLast();
}
void gLattyNode::nextParam()
{
    m_params.next();
}
gLattyNode *gLattyNode::param()
{
    return m_params.value();
}
gLattyNode *gLattyNode::param(const gString &sident)
{
    gLattyNode *lnode;
    m_params.setFirst();
    while(m_params.node())
    {
        lnode = m_params.value();
        if(lnode->identifier() == sident)
        {
            return lnode;
        }
        m_params.next();
    }
    return 0;
}
gLattyNode *gLattyNode::param(gs32 nid)
{
    gLattyNode *lnode;
    m_params.setFirst();
    while(m_params.node())
    {
        lnode = m_params.value();
        if(lnode->id() == nid)
        {
            return lnode;
        }
        m_params.next();
    }
    return 0;
}
bool gLattyNode::hasParameters() const
{
    return m_params.isEmpty() == false;
}
void gLattyNode::setMember(const gString &sid, gs32 nid, gs32 ntype)
{
    m_member = new gLattyNode(sid,0,nid,ntype);
    m_member->setMalden(this);
}
void gLattyNode::setProperty(const gString &sid, gs32 nid, gs32 ntype)
{
    m_property = new gLattyNode(sid,0,nid,ntype);
    m_property->setMalden(this);
}
void gLattyNode::setAssignTo(const gString &sid, gs32 nid, gs32 ntype)
{
    m_assignto = new gLattyNode(sid,0,nid,ntype);
    m_assignto->setMalden(this);
}
void gLattyNode::setAssign(const gString &sid, gs32 nid, gs32 ntype)
{
    m_assign = new gLattyNode(sid,0,nid,ntype);
    m_assign->setMalden(this);
}
void gLattyNode::setMalden(gLattyNode *mnode)
{
    m_malden = mnode;
}

const gString &gLattyNode::identifier() const
{
    return m_ident;
}
gs32 gLattyNode::id() const
{
    return m_id;
}
gs32 gLattyNode::type() const
{
    return m_type;
}
gLattyNode *gLattyNode::member()
{
    return m_member;
}
gLattyNode *gLattyNode::property()
{
    return m_property;
}
gLattyNode *gLattyNode::assignTo()
{
    return m_assignto;
}
gLattyNode *gLattyNode::assign()
{
    return m_assign;
}
gLattyNode *gLattyNode::malden()
{
    return m_malden;
}
