#ifndef GCANDELMACHINE_H
#define GCANDELMACHINE_H
#include "base/gcommon.h"
#include "gstring/gstring.h"

namespace gcf
{
class gCandelMachineSand;
class SHARED_GCF gCandelMachine
{
public:
    gCandelMachine();
    ~gCandelMachine();

    void setExpression(const gString &exp);
protected:
    gCandelMachineSand *d;
};
}

#endif // GCANDELMACHINE_H
