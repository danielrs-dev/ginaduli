#ifndef GVARDIMOPERATION_H
#define GVARDIMOPERATION_H
#include "gvardimvariable.h"
#include "gmath/gmathoperations.h"
namespace gcf
{

class gVardimOperation
{
public:
    gVardimOperation();
    ~gVardimOperation();

    void setOperation(gVardimVariable *var1,
                      gVardimVariable *var2,
                      gVardimVariable *res,
                      gs32 optype);
    void resolve();

    gVardimVariable *variable1();
    gVardimVariable *variable2();
    gVardimVariable *result();
protected:
    gVardimVariable *m_var1;
    gVardimVariable *m_var2;
    gVardimVariable *m_res;
    gu32 m_optype;
};
}
#endif // GVARDIMOPERATION_H
