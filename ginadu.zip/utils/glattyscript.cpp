#include "glattyscript.h"
#define STATE_END 15
using namespace gcf;

gLattyScript::gLattyScript():
    m_done(false)
{

}
gLattyScript::~gLattyScript()
{

}
bool gLattyScript::openScript(const gString &filename)
{
    return m_lexer.openScriptFile(filename);
}
void gLattyScript::setScript(const gString &script)
{
    m_lexer.setScript(script);
}
bool gLattyScript::hasErrors() const
{
    return m_errors.isEmpty() == false;
}
void gLattyScript::errorBegin()
{
    m_errors.setFirst();
}
gLattyError *gLattyScript::error()
{
    return m_errors.value();
}
void gLattyScript::errorNext()
{
    m_errors.next();
}
void gLattyScript::parse(bool singleline)
{
    parseMain(singleline);
}
gLattyNode *gLattyScript::walk()
{
    return m_tree.walk();
}
gLattyNode *gLattyScript::walkNode()
{
    return m_tree.walkData();
}
void gLattyScript::clear()
{
    m_tree.clear();
    m_lexer.clear();
}
void gLattyScript::clearDefs()
{
    m_definitions.clear();

}

gLattyDefinition *gLattyScript::addDefinition(const gString &sident, gs32 nid, gs32 ntype)
{
    gLattyDefinition *def = definition(sident);
    if(def)
    {
        return 0;
    }
    def = new gLattyDefinition(sident,nid,ntype);
    m_definitions.append(def);
    return def;
}
gLattyDefinition *gLattyScript::definition()
{
    return m_definitions.value();
}
gLattyDefinition *gLattyScript::definition(const gString &ident)
{
    gLattyDefinition *def;

    m_definitions.setFirst();
    while(m_definitions.node())
    {
        def = m_definitions.value();
        if(def->identifier() == ident)
        {
            return def;
        }
        m_definitions.next();
    }
    return 0;
}
void gLattyScript::firstDefinition()
{
    m_definitions.setFirst();
}
void gLattyScript::nextDefinition()
{
    m_definitions.next();
}
bool gLattyScript::hasDefinitions() const
{
    return m_definitions.isEmpty() == false;
}
void gLattyScript::setMaster()
{
    m_tree.setMaster();
}
void gLattyScript::setChild()
{
    m_tree.setChild();
}
void gLattyScript::setFather()
{
    m_tree.setFather();
}

gLattyNode *gLattyScript::node()
{
    return m_tree.data();
}
gLattyNode *gLattyScript::childNode()
{
    return m_tree.childData();
}
void gLattyScript::firstChild()
{
    m_tree.firstChild();
}
void gLattyScript::lastChild()
{
    m_tree.lastChild();
}
void gLattyScript::nextChild()
{
    m_tree.nextChild();
}
void gLattyScript::addLevel(const gString &sid)
{
    m_tree.addLevel(sid);
}
void gLattyScript::addLevel(gs32 nid)
{
    m_tree.addLevel(nid);
}
bool gLattyScript::inLevel(const gString &sid)
{
    return m_tree.inLevel(sid);
}
bool gLattyScript::inLevel(gs32 nid)
{
    return m_tree.inLevel(nid);
}
// Start of private functions

void gLattyScript::writeError(const gString &smsg, const gString &add)
{
    gString msg;
    gString scol;
    gString sline;
    gLattyError *err;
    gu32 nline = m_lexer.line();
    gu32 ncol = m_lexer.column();
    scol.toNumber(ncol,GSF_ASCII);
    sline.toNumber(nline,GSF_ASCII);

    msg = smsg;
    msg += " Column : ";
    msg += scol;
    msg += " Line: ";
    msg += sline;

    if(m_lexer.tokenString().isEmpty())
    {
        msg += add;
    }
    else
    {
        msg += m_lexer.tokenString();
    }

    err = new gLattyError();
    err->setMsg(msg);
    err->setLine(nline);
    err->setColumn(ncol);

    m_errors.append(err);
}

void gLattyScript::getToken()
{
    m_lexer.getToken(true);

    switch(m_lexer.tokenID1())
    {
    case GTOKEN_EQUAL:
        m_lexer.getToken();
        if(m_lexer.tokenID1() == GTOKEN_GREATTHAN)
        {
            m_lexer.setTokenID1(GTOKEN_LATTYASSIGNTO);
            m_lexer.setTokenString("=>");
        }
        else
        {
            writeError("Expected > after = but we got");
        }
        break;
    case GTOKEN_LESSTHAN:
        m_lexer.getToken();
        if(m_lexer.tokenID1() == GTOKEN_EQUAL)
        {
            m_lexer.setTokenID1(GTOKEN_LATTYASSIGN);
            m_lexer.setTokenString("<=");
        }
        else
        {
            writeError("Expected = after < but we got");
        }
        break;
    }
}
gLattyNode *gLattyScript::addNode(const gString &sid, gLattyNode *nparent, gs32 nid)
{
    gLattyNode *nod = new gLattyNode(sid,nparent,nid);
    m_tree.appendChild(nod);
    return nod;
}
gLattyNode *gLattyScript::addNodeWithDef(const gString &sid, gLattyNode *nparent)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(sid);
    if(def)
    {
        nid = def->id();
    }
    return addNode(sid,nparent,nid);
}
gLattyNode *gLattyScript::addParamWithDef(gLattyNode *nnode, const gString &sident, gs32 ntype)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(sident);
    if(def)
    {
        nid = def->id();
    }
    return nnode->addParam(sident,nid,ntype);
}
void gLattyScript::setMemberWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(ident);
    if(def)
    {
        nid = def->id();
    }
    nnode->setMember(ident,nid,ntype);
}
void gLattyScript::setPropertyWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(ident);
    if(def)
    {
        nid = def->id();
    }
    nnode->setProperty(ident,nid,ntype);
}
void gLattyScript::setAssignToWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(ident);
    if(def)
    {
        nid = def->id();
    }
    nnode->setAssignTo(ident,nid,ntype);
}
void gLattyScript::setAssignWithDef(gLattyNode *nnode, const gString &ident, gs32 ntype)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(ident);
    if(def)
    {
        nid = def->id();
    }
    nnode->setAssign(ident,nid,ntype);
}
gLattyNode *gLattyScript::createNode(const gString &ident, gLattyNode *nparent)
{
    gs32 nid = -1;
    gLattyDefinition *def = definition(ident);
    if(def)
    {
        nid = def->id();
    }
    return new gLattyNode(ident,nparent,nid);
}
void gLattyScript::parseMain(bool singleline)
{
    gLattyNode *lmaster;
    m_done = false;
    // We are on master node
    lmaster = new gLattyNode("LattyScript",0,-1);
    m_tree.setData(lmaster);
    while(!m_done)
    {
        m_lexer.getToken(true);
        switch(m_lexer.tokenID1())
        {
        case GTOKEN_IDENT:
            parseCommand(lmaster,singleline);
            break;
        case GTOKEN_ERROR:
            writeError("Invalid token");
            break;
        case GTOKEN_ENDOF_FILE:
            m_done = true;
            break;
        case GTOKEN_HASH:
            parseComment();
            break;
        }
    }
}

gs32 gLattyScript::parseCodeBlock(gLattyNode *nparent)
{
    bool donecode=false;

    gs32 retval=-1;
    while(!m_done && !donecode)
    {
        getToken();
        switch(m_lexer.tokenID1())
        {
        case GTOKEN_IDENT:
            parseCommand(nparent);
            break;
        case GTOKEN_ERROR:
            break;
        case GTOKEN_ENDOF_FILE:
            m_done = true;
            break;
        case GTOKEN_HASH:
            parseComment();
            break;
        default:
            retval = m_lexer.tokenID1();
            donecode = true;
            break;
        }
    }
    return retval;
}
gString gLattyScript::parseString()
{
    return m_lexer.sweep('"');
}
void gLattyScript::parseComment()
{
    m_lexer.bypass('\n');
}
gs32 gLattyScript::parseParameters(gLattyNode *nnode)
{
    gLattyNode *p;
    int state = 0;
    gs32 retval = -1;
    while(state != STATE_END)
    {
        if(state != 0)
        {
            getToken();
        }
        switch(state)
        {
        case 0://first parameter
        case 2:
            switch(m_lexer.tokenID1()){
            case GTOKEN_IDENT:
                p = addParamWithDef(nnode,m_lexer.tokenString(),GLATTYN_IDENT);
                break;
            case GTOKEN_NUMFLOAT:
                p = addParamWithDef(nnode,m_lexer.tokenString(),GLATTYN_FLOAT);
                break;
            case GTOKEN_NUMINT:
                p = addParamWithDef(nnode,m_lexer.tokenString(),GLATTYN_INTEGER);
                break;
            case GTOKEN_DOUBLEQUOTE:
                p = addParamWithDef(nnode, parseString(),GLATTYN_STRING);
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Expected identifier, number or string but got");
                state = STATE_END;
                break;
            }
            if(state != STATE_END)
            {
                state = 1;
            }
            break;
        case 1:
            //check coma separator
            switch(m_lexer.tokenID1()){
            case GTOKEN_COMA:
                state = 2;
                break;
            case GTOKEN_PERIOD:
                state = 3;
                break;
            case GTOKEN_COLON:
                state = 4;
                break;
            case GTOKEN_PAROPEN:
                state=5;
                break;//sub parameter
            case GTOKEN_PARCLOSE:
            case GTOKEN_LATTYASSIGN:
            case GTOKEN_LATTYASSIGNTO:
            case GTOKEN_SEMICOLON:
            case GTOKEN_CURLYBRAKETOPEN:
                retval = m_lexer.tokenID1();
                state = STATE_END;
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Expected , parameter separator but got");
                state = STATE_END;

            }
            break;
        case 3://dot or member
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
            case GTOKEN_NUMINT:
                if(p->type() != GLATTYN_IDENT)
                {
                    writeError("Cannot add a member to a non ident parameter type");
                    state = STATE_END;
                    break;
                }
                if(p->member())
                {
                    writeError("ERROR: Parameter already has a member");
                    state = STATE_END;
                    break;
                }
                if(m_lexer.tokenID1()==GTOKEN_IDENT)
                {
                    setMemberWithDef(p,m_lexer.tokenString(),GLATTYN_IDENT);
                    p = p->member();
                }
                else
                {
                    p->setMember(m_lexer.tokenString(),-1,GLATTYN_INTEGER);
                }

                state = 1;
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError(gString("Expected ident on parameter ") + p->identifier() + " member but got ");
                state = STATE_END;
            }
            break;
        case 4://value
            if(p->type()!= GLATTYN_IDENT){
                writeError("Cannot add a value to a non ident parameter type");
                state = STATE_END;
                break;
            }
            if(p->property()){
                writeError("ERROR: Parameter already has a Property");
                state = STATE_END;
                break;
            }
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                setPropertyWithDef(p,m_lexer.tokenString(),GLATTYN_IDENT);
                break;
            case GTOKEN_DOUBLEQUOTE:
                setPropertyWithDef(p,parseString(),GLATTYN_STRING);
                break;
            case GTOKEN_NUMINT:
                p->setProperty(m_lexer.tokenString(),-1,GLATTYN_INTEGER);
                break;
            case GTOKEN_NUMFLOAT:
                p->setProperty(m_lexer.tokenString(),-1,GLATTYN_FLOAT);
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Expected value ident,string or numeric value but got");
                state = STATE_END;
            }
            if(state != STATE_END)
            {
                state=1;
                p = p->property();
            }
            break;
        case 5:
            if(parseParameters(p)!= GTOKEN_PARCLOSE)
            {
                writeError(gString("Expected ) on parameter ") + p->identifier());
                state = STATE_END;
            }
            if(state != STATE_END)
            {
                if(p->malden())
                {
                    p = p->malden();
                }
                state=1;
            }
            break;
        }
    }
    return retval;
}
void gLattyScript::parseCommand(gLattyNode *nparent, bool singleline)
{
    gLattyNode *nnode, *wnode = 0;
    int state = 0;
    gs32 paramret = -1;
    while(state != STATE_END)
    {
        if(state != 0)
        {
            getToken();
        }
        switch(state){
        // State 0 parse the command ident
        case 0:
        case 1:
            //Here should not be any error but just in case
            switch(m_lexer.tokenID1())
            {
            //! This should always happen
            case GTOKEN_IDENT:
                //Add the node
                nnode=addNodeWithDef(m_lexer.tokenString(),nparent);
                wnode = nnode;
                //goto to state 1
                state = 2;
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            }
            break;
        case 2:
            //Checking parameter parsing
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
            case GTOKEN_DOUBLEQUOTE:
            case GTOKEN_NUMINT:
            case GTOKEN_NUMFLOAT:
                //Parse parameter
                paramret = parseParameters(wnode);
                if(wnode->malden())
                {
                    wnode = wnode->malden();
                }
                break;
            case GTOKEN_PERIOD:
                state = 3;
                break;
            case GTOKEN_COLON:
                state = 4;
                break;
            case GTOKEN_LATTYASSIGN:
                state = 5;
                break;
            case GTOKEN_LATTYASSIGNTO:
                state = 6;
                break;
            case GTOKEN_PAROPEN:
                getToken();
                paramret = parseParameters(wnode);
                if(paramret!=GTOKEN_PARCLOSE)
                {
                    writeError("Error expected ) but got ");
                    state=STATE_END;
                }
                if(wnode->malden())
                {
                    wnode = wnode->malden();
                }
                paramret=-1;
                break;
            case GTOKEN_SEMICOLON:
                state=STATE_END;
                break;
            case GTOKEN_CURLYBRAKETOPEN:
                m_tree.setChild();
                paramret = parseCodeBlock(nnode);
                if(paramret != GTOKEN_CURLYBRAKETCLOSE)
                {
                    writeError("Expected } but got ");
                }
                m_tree.setFather();
                state = STATE_END;
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Expected end of sentence ; or { but got");
                state = STATE_END;
            }

            if(state == 2)
            {
                switch(paramret)
                {
                case GTOKEN_SEMICOLON:
                    state = STATE_END;
                    break;
                case GTOKEN_CURLYBRAKETOPEN:
                    m_tree.setChild();
                    paramret = parseCodeBlock(nnode);
                    if(paramret != GTOKEN_CURLYBRAKETCLOSE)
                    {
                        writeError("Expected } but got ");
                    }
                    m_tree.setFather();
                    state = STATE_END;
                    break;
                case GTOKEN_LATTYASSIGN:
                    state = 5;
                    break;
                case GTOKEN_LATTYASSIGNTO:
                    state = 6;
                    break;
                case GTOKEN_PARCLOSE:
                    writeError("Unexpected )");
                    state = STATE_END;
                    break;
                }
                //added single line to allow parsing single line commands without the dot coma separator
                if(singleline)
                {
                    //end of line finishes in state = 2
                    state = STATE_END;
                }
            }
            break;
        case 3:
            if(wnode->member())
            {
                writeError("ERROR: Node already has a member");
                state = STATE_END;
                break;
            }
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                setMemberWithDef(wnode,m_lexer.tokenString(),GLATTYN_IDENT);
                break;
            case GTOKEN_NUMINT:
                wnode->setMember(m_lexer.tokenString(),-1,GLATTYN_INTEGER);
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Error expecting, ident or integer on node member");
                state=STATE_END;
            }
            if(state != STATE_END)
            {
                state = 2;
                wnode = wnode->member();
            }
            break;
        case 4:
            if(wnode->property())
            {
                writeError("ERROR: Node already has a property");
                state = STATE_END;
                break;
            }
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                setPropertyWithDef(wnode,m_lexer.tokenString(),GLATTYN_IDENT);
                break;
            case GTOKEN_DOUBLEQUOTE:
                setPropertyWithDef(wnode,parseString(),GLATTYN_STRING);
                break;
            case GTOKEN_NUMINT:
                wnode->setProperty(m_lexer.tokenString(),-1,GLATTYN_INTEGER);
                break;
            case GTOKEN_NUMFLOAT:
                wnode->setProperty(m_lexer.tokenString(),-1,GLATTYN_FLOAT);
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Error expecting, integer, string or ident o node value");
                state = STATE_END;
            }
            if(state != STATE_END)
            {
                state=2;
                wnode = wnode->property();
            }
            break;
        case 5:
            if(wnode->assign())
            {
                writeError("ERROR: Node already has an assign");
                state = STATE_END;break;
            }
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                setAssignWithDef(wnode,m_lexer.tokenString(),GLATTYN_IDENT);
                break;
            case GTOKEN_DOUBLEQUOTE:
                setAssignWithDef(wnode,parseString(),GLATTYN_STRING);
                break;
            case GTOKEN_NUMINT:
                wnode->setAssign(m_lexer.tokenString(),-1,GLATTYN_INTEGER);
                break;
            case GTOKEN_NUMFLOAT:
                wnode->setAssign(m_lexer.tokenString(),-1,GLATTYN_FLOAT);
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Error expecting, integer, string or ident o node value");
                state = STATE_END;
            }
            if(state != STATE_END)
            {
                state = 2;
                wnode = wnode->assign();
            }
            break;
        case 6:
            if(wnode->assignTo())
            {
                writeError("ERROR: Node already has an assign to");
                state = STATE_END;
                break;
            }
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                setAssignToWithDef(wnode,m_lexer.tokenString(),GLATTYN_IDENT);
                break;
            case GTOKEN_DOUBLEQUOTE:
                setAssignToWithDef(wnode,parseString(),GLATTYN_STRING);
                break;
            case GTOKEN_NUMINT:
                wnode->setAssignTo(m_lexer.tokenString(),-1,GLATTYN_INTEGER);
                break;
            case GTOKEN_NUMFLOAT:
                wnode->setAssignTo(m_lexer.tokenString(),-1,GLATTYN_FLOAT);
                break;
            case GTOKEN_ERROR:
                writeError("Invalid Token");
                state = STATE_END;
                break;
            case GTOKEN_ENDOF_FILE:
                writeError("Error: Reached end of file");
                state = STATE_END;
                break;
            default:
                writeError("Error expecting, integer, string or ident o node value");
                state = STATE_END;
            }
            if(state != STATE_END){
                state = 2;
                wnode = wnode->assignTo();
            }
            break;
        }
    }
}
