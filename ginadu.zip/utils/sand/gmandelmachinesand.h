#ifndef GMANDELMACHINESAND_H
#define GMANDELMACHINESAND_H
#include "utils/gmandeloperation.h"
#include "containers/galignedptrlist.h"
#include "containers/galignedlist.h"

namespace gcf
{
struct gMandelMachineSand
{
    gMandelMachineSand()
    {

    }
    ~gMandelMachineSand()
    {

    }

    gMandelVariable *search(const gString &id)
    {
        gMandelVariable *var;
        gu32 i;

        for(i = 0; i < variables.size(); i++)
        {
            var = variables.value(i);
            if(var->identifier() == id)
            {
                return var;
            }
        }
        return 0;
    }
    gAlignedPtrList<gMandelVariable, gDAllocator<gMandelVariable> > variables;
    gAlignedPtrList<gMandelOperation, gDAllocator<gMandelOperation> > operations;
    gAlignedList<gs32> vardus;


};
}
#endif // GMANDELMACHINESAND_H
