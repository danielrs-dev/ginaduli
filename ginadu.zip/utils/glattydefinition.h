#ifndef GLATTYDEFINITION_H
#define GLATTYDEFINITION_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glattydefinition.h
        Description: Implementation of gLattyDefinition class.
****************************************************************************/

#include "glattyparam.h"

namespace gcf
{
class gLattyDefinition
{
public:
    gLattyDefinition():
        m_id(-1),
        m_type(GLATTYN_UNSET)
    {

    }
    gLattyDefinition(const gString &sident, gs32 nid, gs32 ntype):
        m_ident(sident),
        m_id(nid),
        m_type(ntype)
    {

    }
    ~gLattyDefinition()
    {

    }
    void setIdentifier(const gString &sident)
    {
        m_ident = sident;
    }
    void setID(gs32 nid)
    {
        m_id = nid;
    }
    void setType(gs32 ntype)
    {
        m_type = ntype;
    }
    const gString &identifier() const
    {
        return m_ident;
    }
    gs32 id() const
    {
        return m_id;
    }
    gs32 type() const
    {
        return m_type;
    }
protected:
    gString m_ident;
    gs32 m_id;
    gs32 m_type;
};
}
#endif // GLATTYDEFINITION_H
