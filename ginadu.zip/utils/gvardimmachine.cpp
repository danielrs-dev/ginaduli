#include "gvardimmachine.h"
#include "gvardimmachinesand.h"
#include "glattyscript.h"
#include "gstring/gstringlist.h"
using namespace gcf;

gVardimMachine::gVardimMachine():
    d(new gVardimMachineSand)
{

}
gVardimMachine::~gVardimMachine()
{
    delete d;
}
void gVardimMachine::addVariable(const gString &id, const gVariant &value)
{
    gVardimVariable * v = d->search(id,0);
    if(v)
    {
        return;
    }
    v = new gVardimVariable;
    v->setIdentifier(id);
    v->setValue(value);
    d->variables.append(v);
}
void gVardimMachine::addOperation(gs32 type,
                                  const gString &var1id,
                                  const gString &var2id,
                                  const gString &resid)
{
    gVardimOperation *op;
    gVardimVariable *var1 = d->search(var1id);
    gVardimVariable *var2 = d->search(var2id);
    gVardimVariable *res = d->search(resid);
    if(!var1)
    {
        return;
    }

    if(!res)
    {
        return;
    }

    op = new gVardimOperation();
    op->setOperation(var1,var2,res,type);
    d->operations.append(op);

}
void gVardimMachine::addOperation(gs32 type, gu32 var1index, gu32 var2index, gu32 resindex)
{
    gVardimOperation *op;
    gVardimVariable *var1 = d->variables.value(var1index);
    gVardimVariable *var2 = d->variables.value(var2index);
    gVardimVariable *res = d->variables.value(resindex);
    if(!var1)
    {
        return;
    }

    if(!res)
    {
        return;
    }
    op = new gVardimOperation();
    op->setOperation(var1,var2,res,type);
    d->operations.append(op);
}
void gVardimMachine::setVariableValue(const gString &id, const gVariant &value)
{
    gVardimVariable *v = d->search(id);
    if(v)
    {
        v->setValue(value);
    }
}
void gVardimMachine::setVariableValue(gu32 index, const gVariant &value)
{
    gVardimVariable *v = d->variables.value(index);
    if(v)
    {
        v->setValue(value);
    }
}
const gVariant &gVardimMachine::variable(const gString &sid, gu32 *idx) const
{
    gVardimVariable *v = d->search(sid,idx);
    if(v)
    {
        return v->value();
    }
    return d->dummy;
}
const gVariant &gVardimMachine::variable(gu32 index) const
{
    gVardimVariable *v = d->variables.value(index);
    if(v)
    {
        return v->value();
    }
    return d->dummy;
}
void gVardimMachine::clear()
{
    d->operations.clear();
    d->variables.clear();
}
void gVardimMachine::resolve()
{
    gVardimOperation *vop;
    gu32 i;

    for(i = 0; i < d->operations.size(); i++)
    {
        vop = d->operations.value(i);
        if(vop)
        {
            vop->resolve();
        }
    }
}
bool gVardimMachine::load(const gString &lattyscript, gStringList *err, bool *parserrors)
{
    gLattyScript latty;
    gLattyNode *lnode;
    if(!latty.openScript(lattyscript))
    {
        return false;
    }
    latty.parse();
    if(latty.hasErrors())
    {
        gLattyError *errs;
        latty.errorBegin();
        while(latty.error())
        {
            errs = latty.error();
            err->addString(errs->msg());
            latty.errorNext();
        }
        *parserrors = true;
        return false;
    }
    while((lnode = latty.walk())!= 0)
    {
        if(lnode->identifier() == "variables")
        {
            latty.addLevel("variables");
        }
        if(lnode->identifier() == "vardim")
        {
            latty.addLevel("vardim");
        }
        if(latty.inLevel("variables"))
        {
            if(lnode->identifier() == "variable")
            {
                gLattyNode *id,*value;
                id = lnode->param("id");
                value = lnode->param("value");
                if(id && value)
                {
                    gLattyNode *vid,*vvalue;
                    vid = id->property();
                    vvalue = id->property();
                    if(vid && vvalue)
                    {
                        gVariant val;
                        switch(vvalue->type())
                        {
                        case GLATTYN_FLOAT:
                            val = vvalue->identifier().toFloat();
                            break;
                        case GLATTYN_INTEGER:
                            val = vvalue->identifier().toInt();
                            break;
                        default:
                            err->addString("Error: Values must be float or integer");
                            break;
                        }
                        if(!val.isEmpty())
                        {
                            addVariable(vid->identifier(),val);
                        }
                    }
                    else
                    {
                        err->addString("Erros: Missing parameters id,value");
                    }
                }
                else
                {
                    err->addString("ERROR: variable must always id,and value\n"
                                   "parameters");
                }

            }
        }
        if(latty.inLevel("vardim"))
        {
            if(lnode->identifier() == "operation")
            {
                gs32 optype = -1;
                gLattyNode *type,*val1,*val2,*res;
                type = lnode->param("type");
                val1 = lnode->param("value1");
                val2 = lnode->param("value2");
                res = lnode->param("result");
                if(type && val1 && res)
                {
                    gString sval1, sval2,sres;
                    if(type->identifier() == "mult")
                    {
                        optype = GVOP_MUL;
                    }
                    else if(type->identifier() == "sum")
                    {
                        optype = GVOP_SUM;
                    }
                    else if(type->identifier() == "div")
                    {
                        optype = GVOP_DIV;
                    }
                    else if(type->identifier() == "minus")
                    {
                        optype = GVOP_MINUS;
                    }
                    else if(type->identifier() == "pow")
                    {
                        optype = GVOP_POW;
                    }
                    else if(type->identifier() == "sqrt")
                    {
                        optype = GVOP_SQRT;
                    }

                    if(val1->type() == GLATTYN_IDENT)
                    {
                        sval1 = val1->identifier();
                    }
                    else
                    {
                        err->addString("Parameter value1 assignation is not a variable");
                    }
                    if(optype != GVOP_SQRT && optype != GVOP_POW)
                    {
                        if(val2)
                        {
                            if(val2->type() == GLATTYN_IDENT)
                            {
                                sval2 = val2->identifier();
                            }
                        }
                        else
                        {
                            err->addString("Operations mult,sum,div,and minus must a value2");
                        }
                    }
                    if(res->type() == GLATTYN_IDENT)
                    {
                        sres = res->identifier();
                    }
                    else
                    {
                        err->addString("Return parameter result must be an ident");
                    }
                    if(!sval1.isEmpty() && !sres.isEmpty() && optype != -1)
                    {
                        gu32 count = 0;
                        gVardimVariable *var = d->search(sval1);
                        if(!var)
                        {
                            err->addString(gString("Error variable ") + sval1 +" has not been added");
                            count++;
                        }
                        if(optype != GVOP_SQRT && optype != GVOP_POW)
                        {
                            var = d->search(sval2);
                            if(!var)
                            {
                                err->addString(gString("Error variable ") + sval1 +" has not been added");
                                count++;
                            }
                        }
                        var = d->search(sres);
                        if(!var)
                        {
                            err->addString(gString("Error variable ") + sval1 +" has not been added");
                            count++;
                        }
                        if(count == 0)
                        {
                            addOperation(optype,sval1,sval2,sres);
                        }
                    }
                }
            }
        }
    }
    return true;

}
