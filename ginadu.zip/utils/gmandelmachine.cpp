#include "gmandelmachine.h"
#include "sand/gmandelmachinesand.h"


using namespace gcf;

gMandelMachine::gMandelMachine():
    d(new gMandelMachineSand)
{

}
gMandelMachine::~gMandelMachine()
{
    delete d;
}

gMandelVariable *gMandelMachine::addVariable(const gString &ident, const gVariant &value)
{
    gMandelVariable *var = d->search(ident);
    if(var)
    {
        return 0;
    }
    var = new gMandelVariable();
    var->setIdentifier(ident);
    var->setValue(value);
    d->variables.append(var);
    return var;
}
gMandelVariable *gMandelMachine::variable(const gString &ident)
{
    return d->search(ident);
}
gMandelVariable *gMandelMachine::variable(gu32 index)
{
    return d->variables.value(index);
}
gu32 gMandelMachine::variableCount() const
{
    return d->variables.size();
}
gMandelOperation *gMandelMachine::addOperation(const gString &svar1, const gString &svar2, gs32 oper, gs32 mode)
{
    gMandelOperation *mop;
    gMandelVariable *var1 = d->search(svar1);
    gMandelVariable *var2 = d->search(svar2);

    if(var1 == 0 || var2 == 0)
    {
        return 0;
    }

    mop = new gMandelOperation();
    mop->setVariable1(var1);
    mop->setVariable2(var2);
    mop->setOperation(oper);
    mop->setMode(mode);
    d->operations.append(mop);
    return mop;
}
gMandelOperation *gMandelMachine::addOperation(gu32 var1index, gu32 var2index, gs32 oper, gs32 mode)
{
    gMandelOperation *mop;
    gMandelVariable *var1 = d->variables.value(var1index);
    gMandelVariable *var2 = d->variables.value(var2index);

    if(var1 == 0 || var2 == 0)
    {
        return 0;
    }

    mop = new gMandelOperation();
    mop->setVariable1(var1);
    mop->setVariable2(var2);
    mop->setOperation(oper);
    mop->setMode(mode);
    d->operations.append(mop);
    return mop;
}

gMandelOperation *gMandelMachine::operation(gu32 index)
{
    return d->operations.value(index);
}
gu32 gMandelMachine::operationCount() const
{
    return d->operations.size();
}

void gMandelMachine::addVardu(gs32 val)
{
    d->vardus.append(val);
}
gs32 gMandelMachine::vardu(gu32 index)
{
    return d->vardus.value(index);
}
gu32 gMandelMachine::varduCount() const
{
    return d->vardus.size();
}
bool gMandelMachine::solve()
{
    gMandelOperation *op;
    gu32 i,j = 0;
    gs32 v;
    bool result = true;

    for(i = 0; i < d->operations.size(); i++)
    {
        op = d->operations.value(i);
        op->exec();

        if(i > 0)
        {
            v = d->vardus.value(j);
            j++;
            switch(v)
            {
            case GMANDELV_AND:
                result = result && op->result();
                break;
            case GMANDELV_OR:
                result = result || op->result();
                break;
            }
        }
        else
        {
            result = op->result();
        }

    }
    return result;

}

void gMandelMachine::clear()
{
    d->variables.clear();
    d->vardus.clear();
}
