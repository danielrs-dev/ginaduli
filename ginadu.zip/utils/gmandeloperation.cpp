#include "gmandeloperation.h"


using namespace gcf;


gMandelOperation::gMandelOperation():
    m_var1(0),
    m_var2(0),
    m_result(false),
    m_op(GMANDELOP_NOTSET)
{

}

gMandelOperation::~gMandelOperation()
{

}

void gMandelOperation::setVariable1(gMandelVariable *var1)
{
    m_var1 = var1;
}
void gMandelOperation::setVariable2(gMandelVariable *var2)
{
    m_var2 = var2;
}
void gMandelOperation::setOperation(gs32 oper)
{
    m_op = oper;
}
void gMandelOperation::setMode(gs32 nmode)
{
    m_mode = nmode;
}

void gMandelOperation::setResult(bool res)
{
    m_result = res;
}

gMandelVariable *gMandelOperation::variable1()
{
    return m_var1;
}
gMandelVariable *gMandelOperation::variable2()
{
    return m_var2;
}
gs32 gMandelOperation::operation() const
{
    return m_op;
}
gs32 gMandelOperation::mode() const
{
    return m_mode;
}
bool gMandelOperation::result() const
{
    return m_result;
}
void gMandelOperation::exec()
{
    if(m_var1 == 0 || m_var2 == 0)
    {
        return;
    }
    switch(m_mode)
    {
    case GMANDELMOD_VALUES:
        execValues();
        break;
    case GMANDELMOD_STRINGA:
        execStringA();
        break;
    case GMANDELMOD_STRINGB:
        execStringB();
        break;
    case GMANDELMOD_DATES:
        execDates();
        break;
    default:
        break;
    }

}
void gMandelOperation::execValues()
{
    switch(m_op)
    {
    case GMANDELOP_EQUAL:
        m_result = m_var1->value() == m_var2->value();
        break;
    case GMANDELOP_NOTEQUAL:
        m_result = m_var1->value() != m_var2->value();
        break;
    case GMANDELOP_LESS:
        m_result = m_var1->value() < m_var2->value();
        break;
    case GMANDELOP_GREAT:
        m_result = m_var1->value() > m_var2->value();
        break;
    case GMANDELOP_LESSOREQUAL:
        m_result = m_var1->value() <= m_var2->value();
        break;
    case GMANDELOP_GREATOREQUAL:
        m_result = m_var1->value() >= m_var2->value();
        break;
    default:
        m_result = false;
    }
}
void gMandelOperation::execStringA()
{
    switch(m_op)
    {
    case GMANDELSAOP_EQUAL:
        m_result = m_var1->value() == m_var2->value();
        break;
    case GMANDELSAOP_NOTEQUAL:
        m_result = m_var1->value() != m_var2->value();
        break;
    }
}

void gMandelOperation::execStringB()
{
    gs32 r;
    const gString &var1 = m_var1->value().toString();
    const gString &var2 = m_var2->value().toString();
    r = var1.inString(var2, 0);
    switch(m_op)
    {
    case GMANDELSBOP_INSTRING:
        m_result = (r != -1);
        break;
    case GMANDELSBOP_OUTSTRING:
        m_result = (r == -1);
        break;
    }
}
void gMandelOperation::execDates()
{
    execValues();
}
