#include "gurl.h"

using namespace gcf;

struct gUrlQueryPair
{
    gUrlQueryPair()
    {

    }
    gUrlQueryPair(const gString &q, const gString &v):
        query(q),
        value(v)
    {

    }

    gString query;
    gString value;
};

gUrl::gUrl():
    m_error(false)
{

}
gUrl::gUrl(const gUrl &other)
{
    copy(other);
}
gUrl::gUrl(const gString &surl)
{
    setUrl(surl);
}
gUrl::~gUrl()
{

}
void gUrl::clear()
{
    m_fullurl.clear();
    m_host.clear();
    m_abspath.clear();
    m_scheme.clear();
    m_query.clear();
    m_fragment.clear();
    m_user.clear();
    m_password.clear();
    m_tld.clear();
    m_domain.clear();
    m_port.clear();
    m_file.clear();
    m_subdomains.clear();
    m_path.clear();
    m_empty.clear();
    m_error = false;
}
void gUrl::copy(const gUrl &curl)
{
    m_fullurl = curl.m_fullurl;
    m_host = curl.m_host;
    m_abspath = curl.m_abspath;
    m_scheme = curl.m_scheme;
    m_query = curl.m_query;
    m_fragment = curl.m_fragment;
    m_user = curl.m_user;
    m_password = curl.m_password;
    m_tld = curl.m_tld;
    m_domain = curl.m_domain;
    m_port = curl.m_port;
    m_file = curl.m_file;
    m_subdomains = curl.m_subdomains;
    m_path = curl.m_path;
    m_empty = curl.m_empty;
    m_error = curl.m_error;
}
void gUrl::setUrl(const gString &surl)
{
    clear();
    m_fullurl = surl;
    parse();
}
const gString &gUrl::host() const
{
   return m_host;
}

const gString &gUrl::domain() const
{
   return m_domain;
}
const gString &gUrl::subDomain(gu32 index) const
{
    const gString *sd = m_subdomains.value(index);
    if(sd)
    {
        return *sd;
    }
    else
    {
        return m_empty;
    }
}
gu32 gUrl::subDomainCount() const
{
   return m_subdomains.size();
}
const gString &gUrl::path(gu32 index) const
{
    const gString *p = m_path.value(index);
    if(p)
    {
        return *p;
    }
    else
    {
        return m_empty;
    }

}
gu32 gUrl::pathCount() const
{
   return m_path.size();
}
bool gUrl::containsPath(const gString &name, gu32 *indexOut) const
{
   return m_path.contains(name,indexOut);
}
const gString &gUrl::absPath() const
{
    return m_abspath;
}

const gString &gUrl::query(const gString &key) const{

    const gString *value = m_query.value(key);
    if(value)
    {
        return (*value);
    }
    else
    {
        return m_empty;
    }

}
bool gUrl::containsQuery(const gString &key) const
{
    return m_query.contains(key);
}
const gString &gUrl::fragment() const
{
    return m_fragment;
}
const gString &gUrl::url() const
{
   return m_fullurl;
}

const gString &gUrl::scheme() const
{
   return m_scheme;
}

const gString &gUrl::user() const
{
   return m_user;
}
const gString &gUrl::password() const
{
   return m_password;
}
gs32 gUrl::port() const
{
    if(m_port.isNumeric())
    {
        return m_port.toInt();
    }
    return -1;
}

void gUrl::parse()
{
    gu32 lastposition;
    gLexer lexer;



    lexer.setScript(m_fullurl);
    if(parseScheme(lexer) == false)
    {
        lexer.reset();
    }
    lastposition = lexer.position();
    if(parseUserPassword(lexer) == false)
    {
        lexer.setPosition(lastposition);
    }
    lastposition = lexer.position();
    if(parseDomains(lexer) == false)
    {
        lexer.setPosition(lastposition);
    }
    parsePath(lexer);
}

bool gUrl::parseScheme(gLexer &lexer)
{
    gString s;
    bool found = false;
    int state = 15;
    int diagcount = 0;
    lexer.getToken();
    if(lexer.tokenID1() == GTOKEN_IDENT)
    {
        s = lexer.tokenString();
        state = 0;
    }
    while(state != 15)
    {
        if(diagcount < 2)
        {
            lexer.getToken();
        }
        switch(state)
        {
        case 0:
            if(lexer.tokenID1() == GTOKEN_COLON)
            {
                state = 1;
            }
            else
            {
                state = 15;
            }
            break;
        case 1:
            if(lexer.tokenID1() == GTOKEN_SLASH && diagcount < 2)
            {
                diagcount++;
            }
            else
            {
                state = 15;
            }
            if(diagcount == 2)
            {
                state = 15;
                found = true;
            }
            break;
        }
    }
    if(found)
    {
        m_scheme = s;
    }
    return found;
}

bool gUrl::parseUserPassword(gLexer &lexer)
{
    int state = 0;
    gString u,p;
    while(state!=15)
    {
        lexer.getToken();
        switch(state)
        {
        case 0:
            if(lexer.tokenID1() == GTOKEN_IDENT){
                if(u.isEmpty())
                {
                    u = lexer.tokenString();
                    state = 1;
                }
                else if(p.isEmpty())
                {
                    p = lexer.tokenString();
                    state = 3;
                }
                else{
                    state = 15;
                }
            }
            else
            {
                state = 15;
            }
            break;
        case 1:
            if(lexer.tokenID1() == GTOKEN_COLON)
            {
                state = 0;
            }
            else
            {
                state = 15;
            }
            break;
        case 3:
            if(lexer.tokenID1() != GTOKEN_ATSIGN){

                u.clear();
                p.clear();
            }
            state = 15;
            break;
        }
    }
    if(!u.isEmpty() && !p.isEmpty())
    {
        m_user = u;
        m_password = p;
        return true;
    }
    return false;
}

bool gUrl::parseDomains(gLexer &lexer)
{
    int state = 0;
    gu32 i;
    gu32 nsize;
    gAlignedPtrList<gString> doms;
    gString *str;
    //the mechanics is going from ident dot ident dot until we get something else
    while(state!=15)
    {
        lexer.getToken();
        switch(state)
        {
        case 0: //  ident
            if(lexer.tokenID1() == GTOKEN_IDENT)
            {
                doms.append(new gString(lexer.tokenString()));
                state = 1;
            }
            else
            {
                state = 15;
            }
            break;
        case 1:
            if(lexer.tokenID1() == GTOKEN_PERIOD)
            {
                state = 0;
            }
            else if(lexer.tokenID1() == GTOKEN_COLON)
            { // a port
                state = 2;
            }
            else
            {
                state = 15;
            }
            break;
        case 2:
            if(lexer.tokenID1() == GTOKEN_NUMINT)
            {
                m_port = lexer.tokenString();
            }
            //expected to be the end.
            state = 15;
            break;
        }
    }
    //our tld must be
    if(doms.isEmpty() == false)
    {
        nsize = doms.size();
        if(nsize == 1)
        {
            str = doms.value(0);
            m_tld = (*str);
            m_host = m_tld;
        }
        else if(nsize == 2)
        {
            str = doms.value(0);
            m_domain = *str;
            str = doms.value(1);
            m_tld = *str;
        }
        else
        {
            m_subdomains.alloc(nsize - 2);
            m_subdomains.setUsed(nsize -2);
            for(i = 0; i < nsize - 2; i++)
            {
                str = doms.value(i);
                m_subdomains.setValue(str,i);
            }
            str = doms.value(nsize - 1);
            m_tld = *str;
            str = doms.value(nsize - 2);
            m_domain = *str;
            m_domain.concatenate(".",1);
            m_domain.concatenate(m_tld);

            //build the host
            for(i = 0; i< m_subdomains.size(); i++)
            {
                str = m_subdomains.value(i);
                m_host.concatenate(*str);
                m_host.concatenate(".",i);
            }
            m_host += m_domain;
        }
        //the last token we found we must take it one stepback so the next function could retrieve it
        if(m_port.isEmpty())
        {
            lexer.stepBack();
        }

        return true;
    }
    return false;
}

bool gUrl::parsePath(gLexer &lexer)
{
    //the mechancs is dash/ident/dash/ident dot ident until we get end of file or fragment or query
    gString *v;
    gAlignedPtrList<gString> lpath;
    gString sabspath;
    gString sfragment;
    gString dot;
    gAlignedPtrList<gUrlQueryPair> lquery;
    gUrlQueryPair *qpair;
    gu32 i;
    bool processingFragment = false;
    bool processingQuery  = false;
    int state = 0;

    while(state != 15)
    {
        lexer.getToken();
        switch(state)
        {
        case 0: //Diag
            switch(lexer.tokenID1())
            {
            case GTOKEN_SLASH:
                state = 1;
                break;
            case GTOKEN_PERIOD:
            case GTOKEN_MINUS:
                state = 1;
                dot = lexer.tokenString();
                break;
            case GTOKEN_HASH: //fregment
                if(!processingFragment)
                {
                    state = 2;
                    processingFragment = true;
                }
                else
                {
                    state = 15;
                }

                break;
            case GTOKEN_QUESTIONCLOSE://query
                if(!processingQuery)
                {
                    state = 3;
                    processingQuery = true;
                }
                else{
                    state = 15;
                }
                break;
            case GTOKEN_AND:
                if(processingQuery)
                {
                    state = 3;
                }
                else
                {
                    state = 15;
                }
                break;
            case GTOKEN_EQUAL:
                if(processingQuery)
                {
                    state = 4;
                }
                else
                {
                    state = 15;
                }
                break;
            default:
                state = 15;
            }
            if(state!=15)
            {
                sabspath += lexer.tokenString();
            }
            break;
        case 1://iident
            switch(lexer.tokenID1()){
            case GTOKEN_IDENT:
            case GTOKEN_NUMINT:
            case GTOKEN_NUMFLOAT:
            case GTOKEN_PERIOD:
                sabspath+=lexer.tokenString();
                if(!dot.isEmpty() && !lpath.isEmpty())
                {
                    v = lpath.value(lpath.size() - 1);
                    v->concatenate(dot);
                    v->concatenate(lexer.tokenString());
                    dot.clear();
                }
                else
                {
                    v = new gString(lexer.tokenString());
                    lpath.append(v);
                }
                state = 0;
                break;
            default:
                state = 15;
            }
            break;
        case 2: //fragment
            if(lexer.tokenID1() == GTOKEN_IDENT)
            {
                sfragment = lexer.tokenString();
                state = 0;
            }
            else
            {
                state = 15;
                //error
                m_error = true;
            }
            break;
        case 3: //query ident
            if(lexer.tokenID1() == GTOKEN_IDENT)
            {
                qpair = new gUrlQueryPair(lexer.tokenString(),gString());
                lquery.append(qpair);
                state = 0;
            }
            else{
                state = 15;
            }
            break;
        case 4: //query value
            switch(lexer.tokenID1())
            {
            case GTOKEN_IDENT:
            case GTOKEN_NUMFLOAT:
            case GTOKEN_NUMINT:
                qpair = lquery.value(lquery.size() -1);
                qpair->value = lexer.tokenString();
                state = 0;
                break;
            default:
                state = 15;
            }
            break;
        }
    }
    if(sabspath.isEmpty())
    {
        return false;
    }
    m_abspath = sabspath;
    if(!lquery.isEmpty())
    {
        m_query.setup(lquery.size());
        for(i = 0; i < lquery.size();i++)
        {
            qpair = lquery.value(i);
            m_query.append(qpair->query,new gString(qpair->value));
        }
    }
    m_fragment = sfragment;
    if(lpath.isEmpty() == false)
    {
        m_path.alloc(lpath.size());
        m_path.setUsed(lpath.size());
        for(i = 0; i < lpath.size(); i++)
        {
            v = lpath.value(i);
            m_path.setValue(v,i);
        }
    }
    return true;
}
