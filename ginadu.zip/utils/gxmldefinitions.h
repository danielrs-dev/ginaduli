#ifndef GXMLDEFINITIONS_H
#define GXMLDEFINITIONS_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gxmldefinition.h
        Description: Implementation of gXMLDefinition class.
****************************************************************************/
#include <gstring/gstring.h>
namespace gcf
{
class gXMLDefinition
{
public:
    gXMLDefinition():
        m_id(-1),
        m_type(0)
    {

    }
    ~gXMLDefinition()
    {

    }

    void setID(gs32 nid)
    {
        m_id = nid;
    }
    void setIdentifier(const gString &sident)
    {
        m_ident = sident;
    }
    void setType(gs32 ntype)
    {
        m_type = ntype;
    }
    gs32 id() const
    {
        return m_id;
    }
    const gString &identifier() const
    {
        return m_ident;
    }
    gs32 type() const
    {
        return m_type;
    }
protected:
    gs32 m_id;
    gString m_ident;
    gs32 m_type;
};
}
#endif // GXMLDEFINITIONS_H
