#ifndef GCANDELEXPRESSION_H
#define GCANDELEXPRESSION_H
#include "containers/galignedptrlist.h"
#include "gcandeloperation.h"
#include "gvardimmachine.h"
namespace gcf
{
typedef gAlignedPtrList<gCandelOperation,gDAllocator<gCandelOperation> > gCandelOperations;
class SHARED_GCF gCandelExpression
{
public:
    gCandelExpression();
    ~gCandelExpression();



    void setExpression(const gString &exp);
    const gString &expression() const;
    gVardimMachine *vardim();

    void build();

    const gVariant &solve() const;

    void setVariable(const gString &var, const gVariant &val);
protected:
    gVardimMachine *m_vardim;
    gCandelOperations m_operations;
    gString m_expression;
    gVariant m_solved;
};
}
#endif // GCANDELEXPRESSION_H
