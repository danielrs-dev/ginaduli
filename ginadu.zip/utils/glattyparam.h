#ifndef GLATTYPARAM_H
#define GLATTYPARAM_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glattyparam.h
        Description: Implementation of gLattyParam class.
****************************************************************************/
#include <gstring/gstring.h>

namespace gcf
{
enum LATTYNODE_TYPE
{
    GLATTYN_STRING,
    GLATTYN_INTEGER,
    GLATTYN_FLOAT,
    GLATTYN_IDENT,
    GLATTYN_UNSET,
    GLATTYN_SIZE
};
class gLattyParam
{
public:
    gLattyParam():
        m_type(-1),
        m_member(0)
    {

    }
    gLattyParam(const gString &sident, gs32 ntype):
        m_ident(sident),
        m_type(ntype)
    {

    }
    ~gLattyParam()
    {
        if(m_member)
        {
            delete m_member;
        }
    }
    void setMember(const gString &sident, gs32 ntype)
    {
        m_member = new gLattyParam(sident,ntype);
    }
    void setIdentifier(const gString &sident)
    {
        m_ident = sident;
    }
    void setType(gs32 ntype)
    {
        m_type = ntype;
    }
    const gString &identifier() const
    {
        return m_ident;
    }

    gs32 type() const
    {
        return m_type;
    }
    gLattyParam *member()
    {
        return m_member;
    }

protected:
    gString m_ident;
    gs32 m_type;
    gLattyParam *m_member;
};
}
#endif // GLATTYPARAM_H
