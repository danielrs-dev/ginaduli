#include "gvardimoperation.h"
#include "gmath/gmath.h"
using namespace gcf;

gVardimOperation::gVardimOperation():
    m_var1(0),
    m_var2(0),
    m_res(0),
    m_optype(GVOP_UNSET)
{

}
gVardimOperation::~gVardimOperation()
{

}
void gVardimOperation::setOperation(gVardimVariable *var1,
                                    gVardimVariable *var2,
                                    gVardimVariable *res,
                                    gs32 optype)
{
    m_var1 = var1;
    m_var2 = var2;
    m_res = res;
    m_optype = optype;
}
void gVardimOperation::resolve()
{
    const gVariant &val1 = m_var1->value();
    gVariant val2;

    if(m_var2)
    {
        val2 = m_var2->value();
    }
    gVariant vres;
    switch(m_optype)
    {
    case GVOP_SUM:
        vres = val1 + val2;
        break;
    case GVOP_MINUS:
        vres = val1 - val2;
        break;
    case GVOP_MUL:
        vres = val1 * val2;
        break;
    case GVOP_DIV:
        vres = val1 / val2;
        break;
    case GVOP_SQRT:
        vres = val1;
        vres.squareRoot();
        break;
    case GVOP_POW:
        vres = val1;
        vres.power(val2.toUInt());
        break;
    case GVOP_SIN:

        break;
    }
    m_res->setValue(vres);

}
gVardimVariable *gVardimOperation::variable1()
{
    return m_var1;
}
gVardimVariable *gVardimOperation::variable2()
{
    return m_var2;
}
gVardimVariable *gVardimOperation::result()
{
    return m_res;
}
