#ifndef GXMLATTRIBUTE_H
#define GXMLATTRIBUTE_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gxmlattribute.h
        Description: Implementation of gXMLAtrribute class.
****************************************************************************/
#include <gstring/gstring.h>

namespace gcf
{
class gXMLAttribute
{
public:
    gXMLAttribute()
    {

    }
    ~gXMLAttribute()
    {

    }
    void setName(const gString &mname)
    {
        m_name =mname;
    }
    const gString &name() const
    {
        return m_name;
    }
    void setValue(const gString &mvalue)
    {
        m_value = mvalue;
    }
    const gString &value() const
    {
        return m_value;
    }
    void setLine(gs32 nline)
    {
        m_line = nline;
    }
    void setColumn(gs32 ncolumn)
    {
        m_column = ncolumn;
    }
    gs32 line() const
    {
        return m_line;
    }
    gs32 column() const
    {
        return m_column;
    }
protected:
    gString m_name;
    gString m_value;
    gs32 m_line;
    gs32 m_column;
};
}
#endif // GXMLATTRIBUTE_H
