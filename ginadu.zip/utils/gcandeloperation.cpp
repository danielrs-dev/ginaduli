#include "gcandeloperation.h"

using namespace gcf;


gCandelOperation::gCandelOperation():
    m_operation(GVOP_UNSET)
{

}
gCandelOperation::~gCandelOperation()
{

}
void gCandelOperation::setOperation(gs32 op)
{
    m_operation = op;
}
void gCandelOperation::setValue1(const gString &var, const gVariant &val1)
{
    m_value1.pairA() = var;
    m_value1.pairB() = val1;
}
void gCandelOperation::setValue2(const gString &var ,const gVariant &val2)
{
    m_value2.pairA() = var;
    m_value2.pairB() = val2;
}
void gCandelOperation::setLevel(gs32 nlevel)
{
    m_level = nlevel;
}

gs32 gCandelOperation::operation() const
{
    return m_operation;
}
gs32 gCandelOperation::level() const
{
    return m_level;
}
const gVariant &gCandelOperation::value1() const
{
    return m_value1.pairB();
}
const gVariant &gCandelOperation::value2() const
{
    return m_value2.pairB();
}
const gString &gCandelOperation::var1() const
{
    return m_value1.pairA();
}
const gString &gCandelOperation::var2() const
{
    return m_value2.pairA();
}
