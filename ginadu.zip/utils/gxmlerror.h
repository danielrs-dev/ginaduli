#ifndef GXMLERROR_H
#define GXMLERROR_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gxmlerror.h
        Description: Implementation of gXMLError class.
****************************************************************************/
#include <gstring/gstring.h>

namespace gcf
{
class gXMLError
{
public:
    gXMLError():
        m_line(0),
        m_column(0)
    {

    }
    ~gXMLError()
    {

    }
    void setMsg(const gString &smsg)
    {
        m_msg = smsg;
    }
    void setLine(gs32 nline)
    {
        m_line = nline;
    }
    void setColumn(gs32 ncolumn)
    {
        m_column = ncolumn;
    }
    const gString &msg() const
    {
        return m_msg;
    }
    gs32 line() const
    {
        return m_line;
    }
    gs32 column() const
    {
        return m_column;
    }
protected:
    gString m_msg;
    gs32 m_line;
    gs32 m_column;
};
}
#endif // GXMLERROR_H
