#include "gcandelexpression.h"

using namespace gcf;

gCandelExpression::gCandelExpression():
    m_vardim(new gVardimMachine())
{

}
gCandelExpression::~gCandelExpression()
{
    delete m_vardim;
}


void gCandelExpression::setExpression(const gString &exp)
{
    m_expression = exp;
}
const gString &gCandelExpression::expression() const
{
    return m_expression;
}
gVardimMachine *gCandelExpression::vardim()
{
    return m_vardim;
}
void gCandelExpression::build()
{
    gCandelOperation *ops;

    gu32 i;
    gString reg[5];

    m_vardim->clear();

    reg[0] = "r01";
    reg[1] = "r02";
    reg[2] = "r02";
    reg[3] = "r03";
    reg[4] = "r04";
    for(i = 0; i < m_operations.size(); i++)
    {
        ops = m_operations.value(i);

        m_vardim->addVariable(ops->var1(),ops->value1());
        m_vardim->addVariable(ops->var2(),ops->value2());

    }
    for(i = 0; i < m_operations.size(); i++)
    {
        ops = m_operations.value(i);


    }
}
