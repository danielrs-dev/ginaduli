#include "glexer.h"
#include <io/gfile.h>
using namespace gcf;

gLexer::gLexer():
    m_position(0),
    m_line(0),
    m_column(0)
{

}
gLexer::~gLexer()
{

}
void gLexer::clear()
{
    m_script.clear();
    m_position = 0;
    m_line = 0;
    m_column = 0;
}

bool gLexer::openScriptFile(const gString &filename)
{
    gFile file;

    if(file.open(filename,GFILEAM_READ) == false)
    {
        return false;
    }
    m_script = file.readAllString(GSF_ASCII,GSF_ASCII);
    return true;

}
void gLexer::setScript(const gString &sscript)
{
    m_script = sscript;
}

void gLexer::setPosition(gu32 nposition)
{
    m_position = nposition;
}

char *gLexer::scriptPosition(gu32 nposition)
{
    char *pstr = m_script.asciiData();
    return &pstr[nposition];
}
void gLexer::setTokenID1(gs32 nid)
{
    m_token.setID1(nid);
}
void gLexer::setTokenID2(gs32 nid)
{
    m_token.setID2(nid);
}
void gLexer::setTokenString(const gString &str)
{
    m_token.setString(str);
}

void gLexer::getToken()
{
    char c;
    gs32 start,end;
    char *scriptdata = m_script.asciiData();
    char lastc;
    gString str;
    int state = 1;

    m_token.clear();

    while(state != -1)
    {
        c = getChar();
        if(c != 125)
        {
            c = isAlpha(c);
            if(c != 65)
            {
                c = isNumber(c);
            }
        }
        switch(c)
        {
        case 65:
            state = GTOKEN_IDENT;
            break;
        case 30:
            state = GTOKEN_NUMINT;
            break;
        case '(':
            m_token.setID1(GTOKEN_PAROPEN);
            m_token.setString("(");
            state = -1;
            break;
        case ')':
            m_token.setID1(GTOKEN_PARCLOSE);
            m_token.setString(")");
            state = -1;
            break;
        case '[':
            m_token.setID1(GTOKEN_SQUAREBRAKETOPEN);
            m_token.setString("[");
            state = -1;
            break;
        case ']':
            m_token.setID1(GTOKEN_SQUAREBRAKETCLOSE);
            m_token.setString("]");
            state = -1;
            break;
        case '{':
            m_token.setID1(GTOKEN_CURLYBRAKETOPEN);
            m_token.setString("{");
            state = -1;
            break;
        case '}':
            m_token.setID1(GTOKEN_CURLYBRAKETCLOSE);
            m_token.setString("}");
            state = -1;
            break;
        case ',':
            m_token.setID1(GTOKEN_COMA);
            m_token.setString(",");
            state = -1;
            break;
        case ';':
            m_token.setID1(GTOKEN_SEMICOLON);
            m_token.setString(";");
            state = -1;
            break;
        case ':':
            m_token.setID1(GTOKEN_COLON);
            m_token.setString(":");
            state = -1;
            break;
        case '"':
            m_token.setID1(GTOKEN_DOUBLEQUOTE);
            m_token.setString("\"");
            state = -1;
            break;
        case 39:
            m_token.setID1(GTOKEN_SINGLEQUOTE);
            m_token.setString("'");
            state = -1;
            break;
        case '$':
            m_token.setID1(GTOKEN_MONEY);
            m_token.setString("$");
            state = -1;
            break;
        case '%':
            m_token.setID1(GTOKEN_PERCENT);
            m_token.setString("%");
            state = -1;
            break;
        case '&':
            m_token.setID1(GTOKEN_AND);
            m_token.setString("&");
            state = -1;
            break;
        case '|':
            m_token.setID1(GTOKEN_VERITCALBAR);
            m_token.setString("|");
            state = -1;
            break;
        case '/':
            m_token.setID1(GTOKEN_SLASH);
            m_token.setString("/");
            state = -1;
            break;
        case 92:
            m_token.setID1(GTOKEN_BACKSLASH);
            m_token.setString("\\");
            state = -1;
            break;
        case '?':
            m_token.setID1(GTOKEN_QUESTIONCLOSE);
            m_token.setString("?");
            state = -1;
            break;
        case '!':
            m_token.setID1(GTOKEN_EXCLAMATIONCLOSE);
            m_token.setString("!");
            state = -1;
            break;
        case '^':
            m_token.setID1(GTOKEN_CARET);
            m_token.setString("^");
            state = -1;
            break;
        case '.':
            m_token.setID1(GTOKEN_PERIOD);
            m_token.setString(".");
            state = -1;
            break;
        case '<':
            m_token.setID1(GTOKEN_LESSTHAN);
            m_token.setString("<");
            state = -1;
            break;
        case '>':
            m_token.setID1(GTOKEN_GREATTHAN);
            m_token.setString(">");
            state = -1;
            break;
        case '+':
            m_token.setID1(GTOKEN_PLUS);
            m_token.setString("+");
            state = -1;
            break;
        case '*':
            m_token.setID1(GTOKEN_ASTERISC);
            m_token.setString("*");
            state = -1;
            break;
        case '-':
            m_token.setID1(GTOKEN_MINUS);
            m_token.setString("-");
            state = -1;
            break;
        case '_':
            m_token.setID1(GTOKEN_UNDERSCORE);
            m_token.setString("_");
            state = -1;
            break;
        case '@':
            m_token.setID1(GTOKEN_ATSIGN);
            m_token.setString("@");
            state = -1;
            break;
        case '~':
            m_token.setID1(GTOKEN_TILDE);
            m_token.setString("~");
            state = -1;
            break;
        case '=':
            m_token.setID1(GTOKEN_EQUAL);
            m_token.setString("=");
            state = -1;
            break;
        case '#':
            m_token.setID1(GTOKEN_HASH);
            m_token.setString("#");
            state = -1;
            break;
        case ' ':
            break;
        case '\n':
            m_line++;
            m_column = 0;
            break;
        case 13: //carriage return
            break;
        case 9: // horizontal tab
            break;
        case -125:
            m_token.setID1(GTOKEN_ENDOF_FILE);
            state = -1;
            break;
         default:
            m_token.setID1(GTOKEN_ERROR);
            state = -1;
            break;
        }

        switch(state)
        {
        case GTOKEN_IDENT:
            stepBack(false);
            start = m_position;
            c = getChar();
            end = 0;

            while((isAlpha(c) == 65) || (isNumber(c) == 30) ||
                  (c == '_') || (c == '-'))
            {
                c = getChar();
                end++;
            }
            if(c != 125)
            {
                stepBack(false);
            }
            m_token.setID1(GTOKEN_IDENT);
            str.setString(&scriptdata[start],end);
            m_token.setString(str);
            state = -1;
            break;
         case GTOKEN_NUMINT:
            stepBack(false);
            start = m_position;
            c = getChar();
            end = 0;

            while(isNumber(c) == 30)
            {
                c = getChar();
                end++;
            }
            lastc = lastChar();
            if(c == '.')
            {
                end++;
                c = getChar();
                if(isNumber(c) == 30)
                {
                    while(isNumber(c) == 30)
                    {
                        c = getChar();
                        end++;
                    }
                    if(c != -125)
                    {
                        stepBack(false);
                    }
                    m_token.setID1(GTOKEN_NUMFLOAT);
                    str.setString(&scriptdata[start],end);
                    m_token.setString(str);
                    state = -1;
                }
                else
                {
                    m_token.setID1(GTOKEN_ERROR);
                    state = -1;
                    break;
                }
            }
            else if((c == 'x') && (end == 1) && (lastc == '0'))
            {
                end++;
                start += end;

                c = getChar();
                if(isHex(c))
                {
                    while(isHex(c))
                    {
                        c = getChar();
                        end++;
                    }
                    stepBack(false);
                    m_token.setID1(GTOKEN_CSTYLEHEX);
                    str.setString(&scriptdata[start],end);
                    m_token.setString(str);
                    state = -1;
                }
                else
                {
                    m_token.setID1(GTOKEN_ERROR);
                    state = -1;
                    break;
                }
            }
            else
            {
                if(c != -125)
                {
                    stepBack(false);
                }
                m_token.setID1(GTOKEN_NUMINT);
                str.setString(&scriptdata[start],end);
                m_token.setString(str);
                state = -1;
            }
        break;
        case 1:
            break;
        case -1:
            break;
        case -125:
            break;
        default:
            m_token.setID1(GTOKEN_ERROR);
            state = -1;
        }
    }
}

void gLexer::getToken(bool negvalues)
{
    gString resstr;
    if(negvalues == false)
    {
        getToken();
        return;
    }
    getToken();
    if(m_token.id1() == GTOKEN_MINUS)
    {
        getToken();
        if(m_token.id1() == GTOKEN_NUMINT || m_token.id1() == GTOKEN_NUMFLOAT)
        {
            resstr.setString("-");
            resstr.concatenate(m_token.string());
            m_token.setString(resstr);
        }
        else
        {
            stepBack();
        }
    }
}
const gToken &gLexer::token() const
{
    return m_token;
}
const gString &gLexer::script() const
{
    return m_script;
}
gu32 gLexer::position() const
{
    return m_position;
}
gu32 gLexer::line() const
{
    return m_line;
}
gu32 gLexer::column() const
{
    return m_column;
}
gu32 gLexer::scriptSize() const
{
    return m_script.size();
}
void gLexer::reset()
{
    m_position = 0;
    m_line = 0;
    m_column = 0;
}
char gLexer::currentChar()
{
    char *sdata = m_script.asciiData();
    if(sdata)
    {
        return sdata[m_position];
    }
    else
    {
        return -1;
    }
}
char gLexer::nextChar()
{
    char rch = getChar();
    if(rch == '\n')
    {
        m_line++;
    }
    return rch;
}
gu32 gLexer::tokenID1() const
{
    return m_token.id1();
}
gu32 gLexer::tokenID2() const
{
    return m_token.id2();
}
const gString &gLexer::tokenString() const
{
    return m_token.string();
}
gString gLexer::sweep(char scharacter)
{
    char *sbuff = scriptPosition(m_position);
    gString rstr;
    gu32 ssize = 0;
    char c = currentChar();

    while(c != scharacter && c > 0)
    {
        ssize++;
        nextChar();
        c = currentChar();
    }
    nextChar();
    rstr.setString(sbuff,ssize);
    rstr.setShared(true);
    return rstr;

}
gString gLexer::sweep(const char *cst, gu32 nsize, bool skipsc)
{
    gString rstr;
    gu32 ssize = 0;
    char *buff = scriptPosition(m_position);
    char c = currentChar();
    gu32 i, count = 0;
    bool done = false;

    while(!done && c > 0)
    {
        for(i = 0; i < nsize; i++)
        {
            if(c == cst[i])
            {
                count++;
            }
        }
        if(count == nsize)
        {
            done = true;
        }
        else
        {
            count = 0;
            nextChar();
            c = currentChar();
            ssize++;
        }
    }
    if(skipsc)
    {
        nextChar();
    }
    rstr.setString(buff,ssize);
    rstr.setShared(true);
    return rstr;
}

void gLexer::bypass(char scharacter)
{
    char c = currentChar();
    while(c != scharacter && c > 0)
    {
        nextChar();
        c = currentChar();
    }
    nextChar();
}
char gLexer::getChar()
{
    char *sbuff = m_script.asciiData();
    char c;
    if(m_position == m_script.size())
    {
        return -125;
    }
    c = sbuff[m_position];
    m_position++;
    m_column++;
    return c;
}
char gLexer::isAlpha(char ch)
{
    int ret;
    if(ch == -125)
    {
        return ch;
    }
    ret = isalpha(int(ch));
    if(ret)
    {
        return 65;
    }
    else
    {
        return ch;
    }
}
char gLexer::isNumber(char ch)
{
    int ret;
    if(ch == -125)
    {
        return ch;
    }
    ret = isdigit(int(ch));
    if(ret)
    {
        return 30;
    }
    else
    {
        return ch;
    }
}
bool gLexer::isHex(char ch)
{

    char arr[12] = {65,66,67,68,69,70,
                    97,98,99,100,101,102};
    gu32 i;
    if(ch == -125)
    {
        return ch;
    }

    for(i = 0; i < 12; i++)
    {
        if(ch == arr[i])
        {
            return true;
        }
    }
    return false;
}
void gLexer::stepBack(bool token)
{
    if(m_position > 0)
    {
        if(token)
        {
            m_position -= m_token.string().size();
        }
        else
        {
            m_position--;
        }
    }
}
char gLexer::lastChar()
{
    char *bstr = m_script.asciiData();
    if(m_position == 0)
    {
        return bstr[m_position];
    }
    return bstr[m_position - 1];
}

