#ifndef GVARDIMMACHINE_H
#define GVARDIMMACHINE_H
#include <base/gcommon.h>
#include <gstring/gstringlist.h>
#include <containers/galignedptrlist.h>
#include <gvariant/gvariant.h>
#include "gvardimoperation.h"
namespace gcf

{
enum GVARDIMMACHINE_RESULTS
{
    GVMR_GANTEL,
    GVMR_FINAL
};

class gVardimMachineSand;
class SHARED_GCF gVardimMachine
{
public:
    gVardimMachine();
    ~gVardimMachine();

    void addOperation(gs32 type,
                      gu32 var1index,
                      gu32 var2index,
                      gu32 resindex);
    void addOperation(gs32 type,
                      const gString &var1id,
                      const gString &var2id,
                      const gString &resid);
    void addVariable(const gString &id, const gVariant &value);
    void setVariableValue(const gString &id, const gVariant &value);
    void setVariableValue(gu32 index, const gVariant &value);
    const gVariant &variable(gu32 index) const;
    const gVariant &variable(const gString &sid,gu32 *idx) const;
    void clear();
    void resolve();

    bool load(const gString &lattyscript, gStringList *err, bool *parserrors);

protected:
    gVardimMachineSand *d;
   };
}
#endif // GVARDIMMACHINE_H
