#include "gxmlparser.h"

using namespace gcf;


gXMLParser::gXMLParser():
    m_lowcaseattributes(true),
    m_cancel(false)
{

}
gXMLParser::~gXMLParser()
{

}
bool gXMLParser::openScript(const gString &scr)
{
    return m_lexer.openScriptFile(scr);
}
void gXMLParser::setScript(const gString &src)
{
    m_lexer.setScript(src);
}
void gXMLParser::addDefinition(gs32 nid, const gString &sident, gs32 ntype)
{
    gXMLDefinition *def = new gXMLDefinition();
    def->setID(nid);
    def->setIdentifier(sident);
    def->setType(ntype);
    m_definitions.append(def);
}
void gXMLParser::errorBegin()
{
    m_errors.setFirst();
}
gXMLError *gXMLParser::error()
{
    return m_errors.value();
}
void gXMLParser::nextError()
{
    m_errors.next();
}
bool gXMLParser::hasErrors() const
{
    return (m_errors.isEmpty() == false);
}
void gXMLParser::parse()
{
    bool done = false;
    m_tree.clear();
    m_tree.clearLevels();
    m_errors.clear();

    while((done == false) && (m_cancel == false))
    {
        parseMain();
        m_lexer.getToken();
        switch(m_lexer.tokenID1())
        {
        case GTOKEN_ERROR:
            writeError("Invalid Token");
            break;
        case GTOKEN_ENDOF_FILE:
            done = true;
            break;
        default:
            m_lexer.stepBack();
            break;
        }
    }
}

void gXMLParser::setMaster()
{
    m_tree.setMaster();
}
void gXMLParser::setFather()
{
    m_tree.setFather();
}
void gXMLParser::setChild()
{
    m_tree.setChild();
}
gXMLNode *gXMLParser::node()
{
    return m_tree.data();
}
gXMLNode *gXMLParser::childNode()
{
    return m_tree.childData();
}
void gXMLParser::nextChild()
{
    m_tree.nextChild();
}
void gXMLParser::firstChild()
{
    m_tree.firstChild();
}
void gXMLParser::lastChild()
{
    m_tree.lastChild();
}
bool gXMLParser::hasChilds() const
{
    return m_tree.hasChilds();
}
void gXMLParser::setDefinitionsForHTML()
{
    addDefinition(0,"meta",GXMLNT_SINGLE);
    addDefinition(1,"link",GXMLNT_SINGLE);
    addDefinition(2,"img",GXMLNT_SINGLE);
    addDefinition(3,"br",GXMLNT_SINGLE);
    addDefinition(4,"script",GXMLNT_NESTED_IGNORE);
    addDefinition(5,"style",GXMLNT_NESTED_IGNORE);
    addDefinition(6,"input",GXMLNT_SINGLE);
    addDefinition(7,"frame",GXMLNT_SINGLE);
    addDefinition(8,"hr",GXMLNT_SINGLE);
    addDefinition(9,"base",GXMLNT_SINGLE);
    addDefinition(10,"basefont",GXMLNT_SINGLE);
    addDefinition(11,"col",GXMLNT_SINGLE);
    addDefinition(12,"param",GXMLNT_SINGLE);
}
gXMLNode *gXMLParser::walk()
{
    return m_tree.walk();
}
gXMLNode *gXMLParser::walkNode()
{
    return m_tree.walkData();
}
void gXMLParser::setLowCaseAttributes(bool set)
{
    m_lowcaseattributes = set;
}
void gXMLParser::setCancel(bool set)
{
    m_cancel =set;
}
bool gXMLParser::isLowCaseAttributes() const
{
    return m_lowcaseattributes;
}
bool gXMLParser::canceled() const
{
    return m_cancel;
}
gu32 gXMLParser::getReservedWord()
{
    gXMLDefinition *def;
    if(m_definitions.isEmpty())
    {
        return GXMLNT_UNASSIGNED;
    }
    m_definitions.setFirst();
    while(m_definitions.node())
    {
        def = m_definitions.value();
        if(m_lexer.tokenString() == def->identifier())
        {
            m_lexer.setTokenID2(def->id());
            return def->type();
        }
        m_definitions.next();
    }
    return GXMLNT_UNASSIGNED;
}
void gXMLParser::writeError(const char *str, const gString &ext)
{
    gXMLError *err;
    gs32 nline,ncol;
    gString sline,scol,msg;

    nline = m_lexer.line();
    ncol = m_lexer.column();
    sline.toNumber(nline,GSF_ASCII);
    scol.toNumber(ncol,GSF_ASCII);

    err = new gXMLError();
    msg = str;
    msg += " Column: ";
    msg += scol;
    msg += " Line: ";
    msg += sline;
    msg += " ";
    if(ext.isEmpty() == false)
    {
        msg += ext;
    }
    else
    {
        msg += m_lexer.tokenString();
    }

    err->setMsg(msg);
    err->setColumn(ncol);
    err->setLine(nline);
    m_errors.append(err);
}

void gXMLParser::parseMain()
{
    m_lexer.getToken();
    switch(m_lexer.tokenID1())
    {
    case GTOKEN_LESSTHAN:
        parseTag();
        break;
    case GTOKEN_ERROR:
        break;
    case GTOKEN_ENDOF_FILE:
        break;
    default:
        m_lexer.stepBack();
        ignoreAndSave("<",1);
        break;
    }
}
void gXMLParser::parseTag()
{
    int state=0;//for the machine state
    gXMLNode *lnode = 0;//The node tag

    gu32 ntype=0;//Got the type
    gString ident;
    gs32 nident;

    while(state!=15 && !m_cancel)
    {
        m_lexer.getToken();
        switch(state)
        {
        case 0://We expect three different tokens an ident a / or a ?
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT://Got an ident
                if(!ntype)
                {
                    ntype = getReservedWord();
                }
                nident = m_lexer.tokenID2();
                ident += m_lexer.tokenString();//Store it on ident
                state = 1;//Set the next state
                break;
            case GTOKEN_SLASH://Expected when it is about an ending tag
                //Set state to the ending tag phase
                state = 2;//cool
                break;
            case GTOKEN_QUESTIONCLOSE://Used on start of XML documents
                //Set the type to SINGLE
                ntype = GXMLNT_SINGLE;
                //state remains in zero
                break;
            case GTOKEN_EXCLAMATIONCLOSE:
                //it is a comment
                parseComment();
                state = 15;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;

            default:
                //Anything else means an error and must be set
                writeError("ERROR: Unexpected ");
                //could be any wrong character so we out
                //state=15;

            }
            //end of state 0
            break;
        case 1://expected from the ident
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                //we got another identificator this means we are facing a set of attributes
                //we rewind the token and call to attribute
                m_lexer.stepBack();
                //we create the node tag
                //set ident to lower
                ident.toLowerCase();//need this function
                lnode = createNode(nident,ident,ntype);
                //we add the node
                m_tree.appendChild(lnode);
                //Go to the  newly created tag in the tree
                m_tree.setChild();
                parseAttribute();


                break;
                //it happens in XML
            case GTOKEN_COLON://so we only attatch the simbol to the name
                ident += ":";//and return the state to 0
                state = 0;
                break;
            case GTOKEN_SLASH://Facint the end of a single node tag for some strict HTML and XML documents
                //we store the data
                //At this point the tag should be created
                //Set the type as single
                ntype = GXMLNT_SINGLE;
                //waiting on state 1 for the closing tag >
                break;
            case GTOKEN_QUESTIONCLOSE:
                //Ignore
                break;
            case GTOKEN_GREATTHAN://End of tag
                if(lnode)
                {
                    if(ntype == GXMLNT_SINGLE)
                    {
                        lnode->setType(ntype);
                        lnode->setClosingTag(true);
                        if(lnode->hasAttributes())
                        {
                            m_tree.setFather();
                        }
                    }
                }
                else
                {
                    //if tag has not been created we create it
                    ident.toLowerCase();
                    lnode = createNode(nident,ident,ntype);
                    m_tree.appendChild(lnode);

                    if(ntype == GXMLNT_SINGLE)
                    {
                        lnode->setClosingTag(true);

                    }
                    else
                    {

                        m_tree.setChild();
                    }

                }
                // if the document the content of the inner tag is ment to be ignore we use the jump function
                if(ntype == GXMLNT_NESTED_IGNORE)
                {
                    jumpToFinalTag();
                }
                //Set the state to end
                state = 15;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            }
            break;//End of state 1
        case 2://Facing a ending tag
            //We expect the end of a tag
            lnode = m_tree.data();//get the current tag
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                //We compare the ident found
                ident += m_lexer.tokenString();
                ident.toLowerCase();//to lower case
                if(lnode->name()== ident)
                {
                    lnode->setClosingTag(true);
                    //Go to father
                    //suppose to be nested?
                    if(lnode->type() ==GXMLNT_UNASSIGNED)
                    {
                        lnode->setType(GXMLNT_NESTED);
                    }
                    m_tree.setFather();
                    state = 3;//Go to state 3
                }
                else
                {
                    //This means we are facing an error of unbalanced tags or the tag is composed with :
                    //and go to state 3
                    state = 3;

                }
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;

            }
            break;
        case 3:
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_GREATTHAN:
                //Anything went great or not
                if(!lnode->closingTag())
                {
                    writeError("WARNING: Unbalanced tag",lnode->name());
                }
                state=15;
                break;
            case GTOKEN_COLON:
                ident += ":";
                //go back to state 2
                state = 2;//we xpect again an ident on 2
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;

            }
        }

    }
}

void gXMLParser::parseComment()
{
    // const gToken **tToken=0;

    int state=0;

    char c;//look
    while(state!=15 && !m_cancel)
    {
        if(state!=1) //Happens when comment data is ignored so no need to getoken
        {
            m_lexer.getToken();
        }
        switch(state)
        {
        case 0:
            //expecting -
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_GUIONNORMAL:
                state = 4;//Goto checking for the other guion
                break;
            case GTOKEN_SQUAREBRAKETOPEN://Dealing with CDATA
                parseCDATA();
                state = 15;
                break;
            case GTOKEN_IDENT://dealing with other unknown data such as the start of a HTML document
                //ignore it
                state = 3;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            }
            break;
        case 1:
            //Ignoring data
            c = m_lexer.currentChar();
            while(c != '-' && c != 0)//Zero means end of file
            {
                c = m_lexer.nextChar();
            }
            //Skip previous
            //c=m_lexer.nextChar();
            if(m_lexer.nextChar() == '-')
            {
                //Go out
                state = 2;
            }
            if(c ==-125)
            {
                writeError("Unexpected end of file");
                state = 15;
            }
            //Stay if not
            break;
        case 2:
            switch(m_lexer.tokenID1())

            {
            case GTOKEN_GREATTHAN:
                state = 15;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                writeError("Crap found");
                break;
            default:
                state = 1;
                //writeError("Expecting > at end of comment",m_lexer);
            }

            break;
        case 3:
            //Ignoring data
            m_lexer.bypass('>');
            state=15;
            break;
        case 4:
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_GUIONNORMAL:
                state = 1;//Comment checking completed
                break;

            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            }


        }

    }
}

void gXMLParser::parseCDATA()
{
    int state = 0;
    int corclose = 0;
    gXMLNode *lnode = 0;
    bool bParsedTag = false;
    while(state!=15 && !m_cancel)
    {

        m_lexer.getToken();
        switch(state)
        {
        case 0: //expecting CDATA
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:
                if(m_lexer.tokenString() == "CDATA")
                {
                    state=1;
                }
                else
                {
                    writeError("Unexpected error, expecting CDATA but got");
                    state = 15;
                }
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            default:

                writeError("Unexpected error, expecting CDATA but got");
                state = 15;

                break;
            }
            break;
        case 1:
            //Expecting [
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_SQUAREBRAKETOPEN:
                state = 2;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            default:

                writeError("Unexpected error, expecting [ but got");
                state = 15;

                break;
            }
            break;
        case 2:
            //Expecting data
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_LESSTHAN:
                parseTag();//Parse a tag
                bParsedTag = true;

                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            case GTOKEN_SQUAREBRAKETCLOSE:
                corclose++;
                if(corclose == 2)
                {
                    state=3;//ending CDATA
                }
                break;
            default: //unknown data
                m_lexer.stepBack();
                lnode = m_tree.data();
                if(lnode->closingTag() == false &&
                   lnode->type() != GXMLNT_SINGLE && bParsedTag)
                {

                    ignoreAndSave("<",1);
                }
                else
                {
                    ignoreAndSave("]",1);
                }
                bParsedTag=false;
                corclose=0;
                break;
            }
            break;
        case 3:
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            case GTOKEN_GREATTHAN://finish CDATA
                state = 15;
                break;
            }
            break;
        }

    }
}
void gXMLParser::parseAttribute()
{
    //Parsing attributes
    int state=0;
    gXMLNode *lnode;
    gString ident;
    gString value;
    lnode = m_tree.data();
    while(state!=15 && !m_cancel)
    {
        m_lexer.getToken();
        switch(state)
        {
        case 0://Ident
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_IDENT:

                ident += m_lexer.tokenString();//Got the ident

                //go to next state
                state = 1;
                break;
            case GTOKEN_GREATTHAN://Facing end of tag
                m_lexer.stepBack();//Go back
                state = 15;
                break;
            case GTOKEN_QUESTIONCLOSE:
                //Ignore
                break;
            case GTOKEN_SLASH://Facing end of tag of single node tags of  strict documents
                m_lexer.stepBack();
                state = 15;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            }
            break;//End of state 0
        case 1:
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_EQUAL:
                //Got the equal go to state 2
                state = 2;
                break;
            case GTOKEN_COLON://For some XML CASES
                ident += ":";
                //go to sate 0
                state = 0;
                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;
            }
            break;
            //end of state 1
        case 2:
            switch(m_lexer.tokenID1())
            {
            case GTOKEN_DOUBLEQUOTE:
                value = m_lexer.sweep('"');
                if(m_lowcaseattributes)
                {
                    value.toLowerCase();
                }
                lnode->addAttribute(ident, value, m_lexer.column(), m_lexer.line());
                value.clear();
                //go back to state 0
                state = 0;
                break;
            case GTOKEN_SINGLEQUOTE:
                value = m_lexer.sweep(39);
                if(m_lowcaseattributes)
                {
                    value.toLowerCase();
                }

                lnode->addAttribute(ident, value, m_lexer.column(), m_lexer.line());
                value.clear();
                state = 0;
                break;
            case GTOKEN_IDENT:
                //Some documents have a lack of sintax on attributes so we parse they attributes as idents
                value = m_lexer.tokenString();
                //to lower everything
                ident.toLowerCase();
                if(m_lowcaseattributes)
                {
                    value.toLowerCase();
                }
                lnode->addAttribute(ident, value, m_lexer.column(), m_lexer.line());
                state = 0;
                break;
            case GTOKEN_HASH:
                //ignore and remain on state 2

                break;
            case GTOKEN_ENDOF_FILE:
                state = 15;//reached end of script
                writeError("Unexpected end of script");
                break;
            case GTOKEN_ERROR:
                //ignore crap
                break;

            }
            //!fixes bug when states remains 2 either by token type cat or token type error
            if(state != 2)
            {
                ident.clear();
            }
            break;

        }


    }
}
void gXMLParser::ignoreAndSave(const char *ch, gs32 nsize)
{
    gString str;
    gXMLNode *lnode;
    str = m_lexer.sweep(ch,nsize,false);

    lnode = createNode(0,str,GXMLNT_DATA);
    m_tree.appendChild(lnode);
}
void gXMLParser::jumpToFinalTag()
{
    int state = 0;
    //   const gToken *tToken=0;
    gXMLNode *lnode;
    lnode= m_tree.data();
    while(state != 15 && !m_cancel)
    {
        m_lexer.getToken();
        if(m_lexer.tokenID1()==GTOKEN_ENDOF_FILE)
        {
            state=15;
        }
        switch(state)
        {
        case 0://
            if(m_lexer.tokenID1() == GTOKEN_LESSTHAN)
            {
                state = 1;
            }

            break;
        case 1:
            if(m_lexer.tokenID1()== GTOKEN_SLASH)
            {
                state = 2;
            }
            else
            {
                state = 0;
            }
            break;
        case 2:

            if(m_lexer.tokenID1() == GTOKEN_IDENT)
            {
                if(lnode->name()==m_lexer.tokenString())
                {
                    state=3;
                }
                else
                {
                    state=0;
                }
            }
            break;
        case 3:
            if(m_lexer.tokenID1() == GTOKEN_GREATTHAN)
            {
                lnode->setClosingTag(true);
                m_tree.setFather();
                state = 15;
            }
            else
            {
                state=0;
            }
            break;
        }


    }
}

gXMLNode *gXMLParser::createNode(gs32 nid, const gString &sname, gs32 ntype)
{
    gXMLNode *lnode = new gXMLNode();
    lnode->setID(nid);
    lnode->setName(sname);
    lnode->setType(ntype);
    return lnode;
}
