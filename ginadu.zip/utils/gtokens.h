#ifndef GTOKENS_H
#define GTOKENS_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gtokens.h
        Description: Enumeration values for tokens.
****************************************************************************/
namespace gcf
{
enum GTOKENS
{
    GTOKEN_IDENT = 100, /// Identifier
    GTOKEN_NUMINT = 101, /// Integer number
    GTOKEN_NUMFLOAT = 102, /// Floating point number
    GTOKEN_PAROPEN = 103, /// Parentheses open (
    GTOKEN_PARCLOSE = 104, /// Parentheses cerrar )
    GTOKEN_SQUAREBRAKETOPEN  = 105, /// Square Braket Open [
    GTOKEN_SQUAREBRAKETCLOSE = 106, /// Square Braket Close ]
    GTOKEN_CURLYBRAKETOPEN = 107, /// Curly Braket Open {
    GTOKEN_CURLYBRAKETCLOSE = 108, /// Curly Braket Close }
    GTOKEN_COMA = 109, /// Coma ,
    GTOKEN_SEMICOLON = 110, /// Semicolon ;
    GTOKEN_COLON = 111, /// Colon :
    GTOKEN_EXCLAMATIONOPEN = 112, /// Exclamation open �
    GTOKEN_DOUBLEQUOTE = 113, /// Double Quote "
    GTOKEN_SINGLEQUOTE = 114, /// Single Quote '
    GTOKEN_MONEY = 115, /// Currency Sign $
    GTOKEN_PERCENT = 116, /// Percent %
    GTOKEN_AND = 117, /// And or ampersand &
    GTOKEN_VERITCALBAR = 118, /// Vertical Bar |
    GTOKEN_SLASH = 119, /// Slash /
    GTOKEN_BACKSLASH = 120,/// Back Slash \
    GTOKEN_QUESTIONOPEN = 121, /// Question Mark Open �
    GTOKEN_QUESTIONCLOSE = 122,  /// Question Mark Close ?
    GTOKEN_EXCLAMATIONCLOSE = 123, /// Exclamation Close !
    GTOKEN_CARET = 124, /// Caret ^
    GTOKEN_PERIOD = 125, /// Period .
    GTOKEN_LESSTHAN = 126, /// Less Than <
    GTOKEN_GREATTHAN  = 127,/// Great Than>
    GTOKEN_PLUS = 128, /// Plus +
    GTOKEN_ASTERISC = 129, /// Asterisc*
    GTOKEN_MINUS = 130, /// Minus-
    GTOKEN_UNDERSCORE = 131,/// Underscore_
    GTOKEN_ATSIGN = 132, /// At Sign @
    GTOKEN_TILDE = 133, /// Tilde ~
    GTOKEN_EQUAL = 134, /// Equal =
    GTOKEN_HASH = 135, /// Hash #
    GTOKEN_GUIONNORMAL = 136, //-
    GTOKEN_CSTYLEHEX = 137,

    GTOKEN_ERROR = 1000, /// Error Token
    GTOKEN_ENDOF_FILE = 2000 /// End of file
};


}

#endif // GTOKENS_H
