#ifndef GMANDELMACHINE_H
#define GMANDELMACHINE_H
#include "gvariant/gvariant.h"
#include "gmandeloperation.h"
namespace gcf
{
enum GMANDEL_VARDUS
{
    GMANDELV_AND,
    GMANDELV_OR
};

class gMandelMachineSand;
class SHARED_GCF gMandelMachine
{
public:
    gMandelMachine();
    virtual ~gMandelMachine();

    gMandelVariable *addVariable(const gString &ident,
                                 const gVariant &value);
    gMandelVariable *variable(const gString &ident);
    gMandelVariable *variable(gu32 index);
    gu32 variableCount() const;

    gMandelOperation *addOperation(const gString &svar1,
                                   const gString &svar2,
                                   gs32 oper,
                                   gs32 mode);
    gMandelOperation *addOperation(gu32 var1index,
                                   gu32 var2index,
                                   gs32 oper,
                                   gs32 mode);
    gMandelOperation *operation(gu32 index);
    gu32 operationCount() const;

    void addVardu(gs32 val);
    gs32 vardu(gu32 index);
    gu32 varduCount() const;

    bool solve();

    void clear();
protected:
    gMandelMachineSand *d;
};
}
#endif // GMANDELMACHINE_H
