#ifndef GSCODER_H
#define GSCODER_H
/**************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gscoder.h
        Description: Implementation of class gSCoder
***************************************************************************/

#include <gstring/gstring.h>
#include <containers/galignedlist.h>
namespace gcf
{
/*! \brief The gSCoder class is an utilty the perfoms a basic
           encoding of strings. It uses a really simple algorithm
           to encode strings.
           The encoder and decoder use a string key as a map along with
           desired string to perform a simple encoding on bi dimensional
           table of 16 bit integers.

           Encoded strings have a hexadecimal format:
           Example string "Hello" encoded to "ff44dadfff44dadf4567".

           The default table creation algorithm is really basic. Function
           defaultSetup() creates a basic table.
*/
class SHARED_GCF gSCoder
{
public:
    /// Constructor
    gSCoder();
    /// Destructor
    ~gSCoder();
    /*! \brief Allocates memory for the coding table.
        \param nwidth: Width of table.
        \param nheight: Height of table.
        \return true if success.
    */
    bool alloc(gu32 nwidth, gu32 nheight);
    /// Clears every data member of the class.
    void clear();
    /// Returns whether the data table is empty or not.
    bool isEmpty() const;
    /*! \brief Creates a 256 x 256 table and fills it
               with data.
        \param brandom: Set true to use random numbers to fill the table.
        \param randomseed: Random seed to use random number generator.
        \return The random seed to generate the table. If randomseed is 0
                zero then it returns the random seed number generated internally
                else it returns randomseed.
    */
    gs32 defaultSetup(bool brandom, gs32 randomSeed = 0);
    /// Sets the encoding key.
    void setKey(const gString &skey);
    /// Gets the encoding key.
    const gString &key() const;
    /*! \brief Sets a value on the table.
        \param Value to set.
        \param nx: X Coordinate of table.
        \param ny: Y Coordinate of table.
    */
    void setValue(gu16 nvalue, gu32 nx, gu32 ny);
    /*! \brief Gets a value from the table.
        \param nx: X Coordinate of value on table.
        \param ny: Y Coordinate of value on table.
        \return Value from table.
    */
    gu16 value(gu32 nx, gu32 ny) const;
    /*! \brief Encodes a string. The encoding key must  be set first.
        \param src: String to encode.
        \return Encoded string.
    */
    gString encode(const gString &src);
    /*! \brief Decodes and previosly encoded string.
               Make sure the encoding key and table are set for the encoded
               string or else function would return an empty string.
        \param encoded: Encoded string to decode.
        \return Decoded string.
    */
    gString decode(const gString &encoded);
    /// Retunrs the table width.
    gu32 width() const;
    /// Returns the table height.
    gu32 height() const;
private:
    /*! \brief Utility function that converts a 16 bit value to
               hexadecimal representation on a string. This function
               is used by gSCoder::encode to translate table values
               to hex string.
        \param val: Value to convert.
        \return String with hexadecimal value of val.
    */
    gString uint16ToHex(gu16 val) const;
    /*! \brief Utility function that splits a string that has a hexadecimal
               representation of values to an array of 16 bit integer values.
               This function is used by gSCoder::decode() to find all values from
               the encoding string.
        \param String with hexadecimal values to split. String size must be
               divisible by four.
        \return An array or list of type gAlignedList<gu16> with splitted values
                translated from hexadecimal to 16 bit integer.
    */
    gAlignedList<gu16> fromHexToUint16Array(const gString &str) const;

protected:
    /// Encoding key string.
    gString m_key;
    /// Coding 2D Table.
    gu16 **m_table;
    /// Width of table
    gu32 m_width;
    /// Height of table.
    gu32 m_height;

};
}


#endif // GSCODER_H
