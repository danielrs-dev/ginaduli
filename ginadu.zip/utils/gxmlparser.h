#ifndef GXMLPARSER_H
#define GXMLPARSER_H
/***************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gxmlparser.h
        Description: Implementation of gXMLParser class.
****************************************************************************/
#include "gxmlnode.h"
#include "gxmldefinitions.h"
#include "gxmlerror.h"
#include <containers/gtree.h>
#include "glexer.h"

namespace gcf
{
class SHARED_GCF gXMLParser
{
public:
    gXMLParser();
    ~gXMLParser();
    bool openScript(const gString &scr);
    void setScript(const gString &src);
    void addDefinition(gs32 nid, const gString &sident, gs32 ntype);
    void errorBegin();
    gXMLError *error();
    void nextError();
    bool hasErrors() const;
    void parse();

    void setMaster();
    void setFather();
    void setChild();
    gXMLNode *node();
    gXMLNode *childNode();
    void nextChild();
    void firstChild();
    void lastChild();
    bool hasChilds() const;

    void setDefinitionsForHTML();
    gXMLNode *walk();
    gXMLNode *walkNode();

    void setLowCaseAttributes(bool set);
    bool isLowCaseAttributes() const;
    void setCancel(bool set);
    bool canceled() const;

private:
    gu32 getReservedWord();
    void writeError(const char *str, const gString &ext = gString());
    void parseMain();
    void parseTag();
    void parseComment();
    void parseCDATA();
    void parseAttribute();
    void ignoreAndSave(const char *ch, gs32 nsize);
    void jumpToFinalTag();
    gXMLNode *createNode(gs32 nid, const gString &name, gs32 ntype);
protected:
    gTree<gXMLNode,gDAllocator<gXMLNode> > m_tree;
    gLinkedList<gXMLError,gDAllocator<gXMLError> > m_errors;
    gLinkedList<gXMLDefinition, gDAllocator<gXMLDefinition> > m_definitions;
    gLexer m_lexer;
    bool m_lowcaseattributes;
    bool m_cancel;
};
}
#endif // GXMLPARSER_H
