#ifndef GMANDELVARIABLE_H
#define GMANDELVARIABLE_H
#include "gvariant/gvariant.h"

namespace gcf
{
class SHARED_GCF gMandelVariable
{
public:
    gMandelVariable();
    virtual ~gMandelVariable();

    void setIdentifier(const gString &ident);
    void setValue(const gVariant &val);

    const gString &identifier() const;
    const gVariant &value() const;

protected:
    gString m_identifier;
    gVariant m_value;
};
}
#endif // GMANDELVARIABLE_H
