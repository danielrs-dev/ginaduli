#ifndef GFILE_H
#define GFILE_H
/**************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: gfile.h
        Description: Implementation of class gFile
***************************************************************************/

#include <cstdlib>
#include <gstring/gstring.h>
#include <gvariant/gvariant.h>

namespace gcf
{
enum GFILE_ACCESSMODES
{
    GFILEAM_READ,
    GFILEAM_WRITE
};


enum GFILE_SEEKORIGINS
{
    GFILE_SEEKSTART = SEEK_SET,
    GFILE_SEEKCURRENT = SEEK_CUR,
    GFILE_SEEKEND = SEEK_END

};
/*! \brief The class gFile is the base object that performs basic operation with
           files. You can open, write and read files easily.
*/
class SHARED_GCF gFile
{
public:
    /// Constructor
    gFile();
    /// Destructor. Closes file if opened.
    ~gFile();
    /*! \brief Opens a file either for reading or writing.
        \param sfilename: The filename string.
        \param fmode: Either GFILEAM_READ or GFILEAM_WRITE
        \return true if success. Else false.
    */
    bool open(const gString &sfilename,gu32 fmode);
    /// Closes the file if opened.
    void close();
    /*! \brief Reads a block from the file to a place on memory.
        \param dest: Destinaton memory to read data.
        \param blocksize: Size of memory block to read.
        \param count: Size of blocks to read.
        \return Number blocks succesfully read.
    */
    gu64 read(void *dest, gu32 blocksize, gu32 count);
    /*! \brief Reads a string block previouly formated on the file.
               This means the file must be written with the proper format
               so it can properly read the string.
               The format is writting a unsigned integer with size of the
               string.
               Then writing the string block. In this way readString
               function knows how to get the string block from the file.
        \param scformat: The format of the string in the file.
        \param scdformat: The output format of this function.
        \return A string containing this string block.
     */
    gString readString(gs32 scformat, gs32 scdformat);
    /*! \brief Reads the entire file as a string. Handy for reading
               text files.
        \param scformat: Format of string or text file.
        \param scdformat: Format of output string of function.
        \return A string containing the entire file data.
    */
    gString readAllString(gs32 scformat, gs32 scdformat);
    /// Reads a 32 bit integer.
    gs32 readInt();
    /// Reads a 64 bit integer.
    gs64 readInt64();
    /// Reads a 32 bit float value.
    gf32 readFloat();
    /// Reads a 64 bit double value.
    gf64 readDouble();
    gVariant readVariant();
    /*! \brief Writes a buffer to the file.
        \param buff: Buffer to write.
        \param blocksize: Size of buffer block.
        \param count: Size or count of blocks to write.
        \return Count of blocks written.
    */
    gu64 write(const void *buff, gu32 blocksize, gu32 count);
    /*! \brief Writes a string to the file.
        \param String object to write.
        \param writeheaders: If set to true headers are written to the file.
                             First 32 integer value is written with size of the string
                             followed by the string data.
        \return Size of characters written to the file.
    */
    gu64 write(const gString &str, bool writeheaders = true);
    gu64 write(const gVariant &var);
    /// Writes a signed 32 bit value.
    gu64 write(gs32 value);
    /// Writes a signed 64 bit value.
    gu64 write(gs64 value);
    /// Writes a 32 float value.
    gu64 write(gf32 value);
    /// Writes a 64 float value.
    gu64 write(gf64 value);
    /*! \brief Moves the file pointer to a position.
        \param offset: Offset to set on file or new position.
        \param origins: Starting point to set the postion.
                        This can be GFILE_SEEKSTART, GFILE_SEEKSET
                        or GFILE_SEEKEND.
    */
    void seek(gu64 offset, gs32 origins);
    /// Returns the current position of the file pointer.
    gu64 position() const;
    /// Returns whether the file reached the end or not.
    bool eof() const;
    /// Returns whether the file is opened or not.
    bool isOpened() const;
    /// Returns the filename.
    const gString &fileName() const;
    /// Returns the size of the file.
    gu64 size() const;
    /*! \brief Writes a buffer to the file of type D.
        \param buff: Buffer to write.
        \param count: Number buffer blocks to write.
        \return Count blocks written in the file.
    */
    template <class D>
    gu64 write(const D *buff,gu32 count)
    {
        return write(buff,sizeof(D),count);
    }
    /*! \brief Reads a buffer from the file of type D.
        \param buff: Buffer to read to.
        \param count: Number buffer blocks to read.
        \return Count blocks read in the file.
    */
    template <class D>
    gu64 read(D *buff,gu32 count)
    {
        return read(buff,sizeof(D),count);
    }
    bool static fileExists(const gString &fname);
protected:
    /// Pointer to the file
    FILE *m_file;
    /// Size of file
    gu64 m_size;
    /// Filename or path
    gString m_filename;


};
}


#endif // GFILE_H
