#include "gfile.h"

using namespace gcf;


gFile::gFile():
    m_file(0),
    m_size(0)
{

}
gFile::~gFile()
{
    close();
}

bool gFile::open(const gString &sfilename, gu32 fmode)
{
    gString openmode;
    gString filestr;
    if(m_file)
    {
        close();
    }
    if(fmode == GFILEAM_READ)
    {
        openmode = "rb";
    }
    else
    {
        openmode = "wb";
    }
    if(sfilename.format() == GSF_UNICODE)
    {
        filestr = sfilename;
        filestr.toAscii();
    }
    else
    {
        filestr = sfilename;
    }

    m_file = fopen(filestr.asciiData(),openmode.asciiData());
    if(m_file)
    {
        fseek(m_file,0L,SEEK_END);
        m_size = ftell(m_file);
        fseek(m_file,0L,SEEK_SET);
        m_filename = filestr;

    }
    return (m_file != 0);
}

void gFile::close()
{
    if(m_file)
    {
        fclose(m_file);
        m_filename.clear();
        m_size = 0;
        m_file = 0;
    }
}
gu64 gFile::read(void *dest, gu32 blocksize, gu32 count)
{
    if(m_file == 0)
    {
        return 0;
    }
    return fread(dest,blocksize,count,m_file);
}
gString gFile::readString(gs32 scformat, gs32 scdformat)
{
    gString ret;
    gu32 blocksize;
    gu32 strsize;
    if(scformat == GSF_ASCII)
    {
        blocksize = sizeof(char);
    }
    else
    {
        blocksize = sizeof(wchar_t);
    }

    strsize = gu32(readInt());
    ret.alloc(strsize,scformat);
    read(ret.asciiData(),blocksize,strsize);

    if(scformat != scdformat)
    {
        if(scdformat == GSF_UNICODE)
        {
            ret.toUnicode();
        }
        else
        {
            ret.toAscii();
        }
    }
    ret.setShared(true);
    return ret;
}
gString gFile::readAllString(gs32 scformat, gs32 scdformat)
{
    gString ret;

    gu32 strsize;

    strsize = m_size;
    ret.alloc(strsize,scformat);
    read(ret.asciiData(),1,strsize);

    if(scformat != scdformat)
    {
        if(scdformat == GSF_UNICODE)
        {
            ret.toUnicode();
        }
        else
        {
            ret.toAscii();
        }
    }
    ret.setShared(true);
    return ret;
}
gs32 gFile::readInt()
{
    gs32 val;
    read<gs32>(&val,1);
    return val;
}
gs64 gFile::readInt64()
{
    gs64 val;
    read<gs64>(&val,1);
    return val;
}
gf32 gFile::readFloat()
{
    gf32 val;
    read<gf32>(&val,1);
    return val;
}
gf64 gFile::readDouble()
{
    gf64 val;
    read<gf64>(&val,1);
    return val;
}
gVariant gFile::readVariant()
{
    gVariant rval;
    gs32 ntype;

    ntype = readInt();
    rval.alloc(ntype);
    if(ntype <= GVARIANT_TYPE_FLOAT64)
    {

        read(rval.toPointer(),rval.size(),1);
    }
    else if(ntype == GVARIANT_TYPE_STRING)
    {
        rval.toString() = readString(GSF_ASCII,GSF_ASCII);
    }
    else if(ntype == GVARIANT_TYPE_VECTOR2F)
    {
        gVector2f &vec = rval.toVector2f();
        vec.x() = readFloat();
        vec.y() = readFloat();
    }
    else if(ntype == GVARIANT_TYPE_DATETIME)
    {
        gDateTime &dt = rval.toDateTime();
        long tdata = readInt64();
        dt.setTimeData(tdata);
    }
    return rval;
}
gu64 gFile::write(const void *buff, gu32 blocksize, gu32 count)
{
    if(m_file == 0)
    {
        return 0;
    }
    return fwrite(buff,blocksize,count,m_file);
}
gu64 gFile::write(const gString &str, bool writeheaders)
{
    gu32 strsize = str.byteSize();
    const char *sdata = str.asciiData();

    if(writeheaders)
    {
        write(gs32(strsize));
    }
    return write<char>(sdata,strsize);
}
gu64 gFile::write(const gVariant &var)
{
    gu64 blocksize = var.size();
    gs32 type = var.type();
    gu64 nret;
    nret = write(type);
    if(type <= GVARIANT_TYPE_FLOAT64)
    {
        nret += write(var.toPointer(),blocksize,1);
    }
    else if(type == GVARIANT_TYPE_STRING)
    {
        nret += write(var.toString(),true);
    }
    else if(type == GVARIANT_TYPE_VECTOR2F)
    {
        const gVector2f &vec = var.toVector2f();
        nret += write(vec.x());
        nret += write(vec.y());
    }
    else if(type == GVARIANT_TYPE_DATETIME)
    {
        const gDateTime &dt = var.toDateTime();
        nret += write((gs64)dt.timeData());
    }

    return nret;
}
gu64 gFile::write(gs32 value)
{
    return write<gs32>(&value,1);
}
gu64 gFile::write(gs64 value)
{
    return write<gs64>(&value,1);
}
gu64 gFile::write(gf32 value)
{
    return write<gf32>(&value,1);
}
gu64 gFile::write(gf64 value)
{
    return write<gf64>(&value,1);
}
void gFile::seek(gu64 offset, gs32 origins)
{
    if(m_file == 0)
    {
        return;
    }
    fseek(m_file,offset,origins);
}
gu64 gFile::position() const
{
    if(m_file == 0)
    {
        return 0;
    }
    return ftell(m_file);
}
bool gFile::eof() const
{
    if(m_file == 0)
    {
        return true;
    }
    return feof(m_file) != 0;
}
bool gFile::isOpened() const
{
    return m_file != 0;
}
gu64 gFile::size() const
{
    return m_size;
}
const gString & gFile::fileName() const
{
    return m_filename;
}
bool gFile::fileExists(const gString &fname)
{
    gFile f;
    return f.open(fname, GFILEAM_READ);
}
