#include "gdatetime.h"
#include "sand/gdatetimesand.h"

using namespace gcf;

gDateTime::gDateTime():
    d(new gDateTimeSand)
{

}
gDateTime::gDateTime(const gDateTime &otime):
    d(new gDateTimeSand)
{
    d->copy(otime.d);
}

gDateTime::~gDateTime()
{
    delete d;
}


void gDateTime::currentTime()
{
    d->currentTime(0);
}

void gDateTime::setSecond(gs32 nsecond)
{
    d->second = nsecond;
}
void gDateTime::setMinute(gs32 nminute)
{
    d->minute = nminute;
}
void gDateTime::setHour(gs32 nhour)
{
    d->hour = nhour;
}
void gDateTime::setDay(gs32 nday)
{
    d->day = nday;
}
void gDateTime::setMonth(gs32 nmonth)
{
    d->month = nmonth;
}
void gDateTime::setYear(gs32 nyear)
{
    d->year = nyear;
}
void gDateTime::setDateTime(const gString &ftime)
{
    d->setFromString(ftime);
}
void gDateTime::setDateTime(gs32 nday, gs32 nmonth, gs32 nyear, gs32 nhour, gs32 nminute, gs32 nsecond)
{
    d->day = nday;
    d->month = nmonth;
    d->year = nyear;
    d->hour = nhour;
    d->minute = nminute;
    d->second = nsecond;

    d->build();
}

gs32 gDateTime::second() const
{
    return d->second;
}
gs32 gDateTime::minute() const
{
    return d->minute;
}
gs32 gDateTime::hour() const
{
    return d->hour;
}
gs32 gDateTime::day() const
{
    return d->day;
}
gs32 gDateTime::month() const
{
    return d->month;
}
gs32 gDateTime::year() const
{
    return d->year;
}
gString gDateTime::asString(gs32 nformat) const
{
    return d->asString(nformat);
}
void gDateTime::build()
{
    d->build();
}

gDateTime &gDateTime::operator = (const gDateTime &o)
{
    d->copy(o.d);
    return *this;
}
gDateTime gDateTime::operator + (const gDateTime &o) const
{
    gDateTime ret;
    (*ret.d) = d->timeArith(o.d,0);

    return ret;
}
gDateTime gDateTime::operator - (const gDateTime &o) const
{
    gDateTime ret;
    (*ret.d) = d->timeArith(o.d,1);

    return ret;
}

bool gDateTime::operator == (const gDateTime &o) const
{
    return d->timeBool(o.d, 0);
}
bool gDateTime::operator != (const gDateTime &o) const
{
    return d->timeBool(o.d, 1);
}
bool gDateTime::operator < (const gDateTime &o) const
{
    return d->timeBool(o.d, 2);
}
bool gDateTime::operator > (const gDateTime &o) const
{
    return d->timeBool(o.d, 3);
}
bool gDateTime::operator <= (const gDateTime &o) const
{
    return d->timeBool(o.d, 4);
}
bool gDateTime::operator >= (const gDateTime &o) const
{
    return d->timeBool(o.d, 5);
}

long gDateTime::timeData() const
{
    return d->stime;
}
void gDateTime::setTimeData(long tdata)
{
    tm *ct;
    d->stime = tdata;
    ct = localtime(&d->stime);

    d->second = ct->tm_sec;
    d->minute = ct->tm_min;
    d->hour = ct->tm_hour;
    d->day = ct->tm_mday;
    d->month = ct->tm_mon;
    d->year = ct->tm_year;

}
