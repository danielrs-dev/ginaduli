#ifndef GDATETIME_H
#define GDATETIME_H
#include "base/gcommon.h"
#include "gstring/gstring.h"

namespace gcf
{
class gDateTimeSand;
class SHARED_GCF gDateTime
{
public:
    gDateTime();
    gDateTime(const gDateTime &otime);
    virtual ~gDateTime();

    void currentTime();

    void setSecond(gs32 nsecond);
    void setMinute(gs32 nminute);
    void setHour(gs32 nhour);
    void setDay(gs32 nday);
    void setMonth(gs32 nmonth);
    void setYear(gs32 nyear);
    void setDateTime(const gString &ftime);
    void setDateTime(gs32 nday, gs32 nmonth, gs32 nyear, gs32 nhour, gs32 nminute, gs32 nsecond);

    gs32 second() const;
    gs32 minute() const;
    gs32 hour() const;
    gs32 day() const;
    gs32 month() const;
    gs32 year() const;

    void build();

    gString asString(gs32 nformat = GSF_ASCII) const;

    gDateTime &operator = (const gDateTime &otime);

    gDateTime operator + (const gDateTime &otime) const;
    gDateTime operator - (const gDateTime &otime) const;

    bool operator == (const gDateTime &otime) const;
    bool operator != (const gDateTime &otime) const;
    bool operator < (const gDateTime &otime) const;
    bool operator > (const gDateTime &otime) const;
    bool operator <= (const gDateTime &otime) const;
    bool operator >= (const gDateTime &otime) const;

    long timeData() const;
    void setTimeData(long tdata);
protected:
    gDateTimeSand *d;

};
}

#endif // GDATETIME_H
