#ifndef GDATETIMESAND_H
#define GDATETIMESAND_H
#include <ctime>
#include "gstring/gstring.h"
#include "utils/glexer.h"
namespace gcf
{
struct gDateTimeSand
{
    gDateTimeSand():
        stime(0),
        second(0),
        minute(0),
        hour(0),
        day(0),
        month(0),
        year(0)
    {

    }
    gDateTimeSand(const gDateTimeSand &o):
        stime(o.stime),
        second(o.second),
        minute(o.minute),
        hour(o.hour),
        day(o.day),
        month(o.month),
        year(o.year)
    {

    }

    ~gDateTimeSand()
    {

    }
    gDateTimeSand &operator = (const gDateTimeSand &o)
    {
        copy(&o);
        return *this;
    }
    void copy(const gDateTimeSand *o)
    {
        stime = o->stime;
        second = o->second;
        minute = o->minute;
        hour = o->hour;
        day = o->day;
        month = o->month;
        year = o->year;
    }

    bool timeBool(const gDateTimeSand *o, gs32 op) const
    {
        switch(op)
        {
        case 0: return (stime == o->stime);
        case 1: return (stime != o->stime);
        case 2: return (stime < o->stime);
        case 3: return (stime > o->stime);
        case 4: return (stime <= o->stime);
        case 5: return (stime >= o->stime);
        default:
            return false;
        }
    }
    gDateTimeSand timeArith(const gDateTimeSand *o, gs32 op) const
    {
        time_t ntime;
        gDateTimeSand ret;
        switch(op)
        {
        case 0: ntime = (stime + o->stime); break;
        case 1: ntime = (stime - o->stime); break;
        default: return gDateTimeSand();
        }
        ret.currentTime(&ntime);
        return ret;

    }

    void currentTime(time_t *ntime)
    {
        if(!ntime)
        {
            stime = time(0);
        }
        else
        {
            stime = (*ntime);
        }
        tm *lt = localtime(&stime);

        second = lt->tm_sec;
        minute = lt->tm_min;
        hour = lt->tm_hour;
        day = lt->tm_mday;
        month = lt->tm_mon;
        year = lt->tm_year;
    }

    void build()
    {
        tm *nt;
        time_t ntime;

        ntime = time(0);
        nt = localtime(&ntime);

        nt->tm_hour = hour;
        nt->tm_sec = second;
        nt->tm_min = minute;
        nt->tm_mday = day;
        nt->tm_mon = month;
        nt->tm_year = year;

        stime = mktime(nt);


    }
    void setFromString(const gString &str)
    {
        // day-month-year hour:minute:hour
        gLexer lx;
        int state = 0;
        int selector = 0;
        gs32 val[6];
        lx.setScript(str);


        while(state != 15)
        {
            lx.getToken();
            switch(state)
            {
            case 0: //day
                if(lx.tokenID1() == GTOKEN_NUMINT)
                {
                    if(selector < 6)
                    {
                        val[selector] = lx.tokenString().toInt();
                    }
                    if(selector < 3)
                    {
                        state = 1;
                    }
                    else if(selector > 3)
                    {
                        state = 2;
                    }
                }
                else
                {
                    state = 15;
                }
                break;
            case 1:
                if(lx.tokenID1() == GTOKEN_MINUS)
                {
                    state = 0;
                    selector++;
                }
                else
                {
                    state = 15;
                }
                break;
            case 2:
                if(lx.tokenID1() == GTOKEN_COLON)
                {
                    state = 0;
                    selector++;
                }
                else
                {
                    state = 15;
                }

            }
        }
        day = val[0];
        month = val[1];
        year = val[2];
        hour = val[3];
        minute = val[4];
        second = val[5];
        build();
    }
    gString asString(gs32 format) const
    {
        gString val;
        gString sday,smonth,syear;
        gString shour,sminute,ssecond;

        sday.toNumber(day,format);
        smonth.toNumber(month,format);
        syear.toNumber(year,format);
        shour.toNumber(hour,format);
        sminute.toNumber(minute,format);
        ssecond.toNumber(second,format);

        val = sday;
        val += "-";
        val += smonth;
        val += "-";
        val += syear;
        val += " ";
        val += shour;
        val += ":";
        val += sminute;
        val += ":";
        val += ssecond;

        val.setShared(true);
        return val;

    }

    time_t stime;
    gs32 second;
    gs32 minute;
    gs32 hour;
    gs32 day;
    gs32 month;
    gs32 year;
};
}

#endif // GDATETIMESAND_H
