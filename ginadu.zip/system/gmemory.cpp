#include "gmemory.h"
#include <cstdlib>
using namespace gcf;

gMemory::gMemory()
{

}
gMemory::~gMemory()
{

}
void *gMemory::alloc(gu32 nsize)
{
    return malloc(nsize);
}

void *gMemory::alloc(gu32 block, gu32 nsize)
{
    return malloc(block * nsize);
}
void *gMemory::ralloc(void *ptr, gu32 nsize)
{
    return realloc(ptr,nsize);
}
void *gMemory::ralloc(void *ptr, gu32 block, gu32 nsize)
{
    return realloc(ptr,block * nsize);
}

void gMemory::dalloc(void *mem)
{
    if(mem)
    {
        free(mem);
    }
}
