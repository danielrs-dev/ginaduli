#ifndef GLIBRARY_H
#define GLIBRARY_H
/**************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glibrary.h
        Description: Implementation of class gLibrary
***************************************************************************/
#include <gstring/gstring.h>
#include "glibrarysand.h"
namespace gcf
{
class SHARED_GCF gLibrary
{
public:
    gLibrary();
    ~gLibrary();

    bool load(const gString &lib);
    void unload();
    void *resolve(const gString &funcname);
    bool isLoaded() const;

    const gString &path() const;
protected:
    gLibrarySand *d;
};
}
#endif // GLIBRARY_H
