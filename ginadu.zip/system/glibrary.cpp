#ifdef WIN32
#include "impl/glibrarywin32.h"
#endif

#ifdef __gnu_linux__
#include "impl/glibrarylinux.h"
#endif

#include "glibrary.h"
using namespace gcf;

gLibrary::gLibrary()
{
#ifdef WIN32
    d = new gLibraryWin32();
#endif
#ifdef __gnu_linux__
    d = new gLibraryLinux();
#endif
}
gLibrary::~gLibrary()
{
    delete d;
}
bool gLibrary::load(const gString &lib)
{
    return d->load(lib);
}
void gLibrary::unload()
{
    d->unload();
}
void *gLibrary::resolve(const gString &funcname)
{
    return d->resolve(funcname);
}
bool gLibrary::isLoaded() const
{
    return d->isLoaded();
}
const gString &gLibrary::path() const
{
    return d->path();
}
