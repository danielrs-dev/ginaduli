#ifndef GLIBRARYLINUX_H
#define GLIBRARYLINUX_H
/**************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glibrarywin32.h
        Description: Implementation of class gLibraryWin32
***************************************************************************/
#ifdef __gnu_linux___
#include <system/glibrarysand.h>
#include <dlfcn.h>
namespace gcf
{
class gLibraryLinux : public gLibrarySand
{
public:
    gLibraryLinux();
    virtual ~gLibraryLinux();
    virtual bool load(const gString &lib);
    virtual void unload();
    virtual void *resolve(const gString &funcname);
    virtual bool isLoaded() const;
protected:
    void *m_libhandle;
};
}
#endif
#endif // GLIBRARYLINUX_H
