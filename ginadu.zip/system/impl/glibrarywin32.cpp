#include "glibrarywin32.h"

using namespace gcf;


gLibraryWin32::gLibraryWin32():
    m_libhandle(0)
{

}
gLibraryWin32::~gLibraryWin32()
{
    unload();
}
bool gLibraryWin32::load(const gString &lib)
{
    gString slib = lib;
    m_libpath = lib;
#ifdef UNICODE
    if(lib.format() == GSF_ASCII)
    {
        slib.toUnicode();
    }
    m_libhandle = LoadLibrary(slib.unicodeData());
#else
    m_libhandle = LoadLibrary(slib.asciiData());
#endif

    return (m_libhandle != 0);
}
void gLibraryWin32::unload()
{
    if(m_libhandle)
    {
        FreeLibrary(m_libhandle);
        m_libpath.clear();
        m_libhandle = 0;
    }
}

void *gLibraryWin32::resolve(const gString &funcname)
{
    if(m_libhandle)
    {
        return (void *)GetProcAddress(m_libhandle,funcname.asciiData());
    }
    return 0;
}
bool gLibraryWin32::isLoaded() const
{
    return (m_libhandle != 0);
}
