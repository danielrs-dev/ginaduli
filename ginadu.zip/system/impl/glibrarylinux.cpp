#ifdef __gnu_linux__
#include "glibrarylinux.h"

using namespace gcf;

gLibraryLinux::gLibraryLinux():
    m_libhandle(0)
{

}

gLibraryLinux::~gLibraryLinux()
{
    unload();
}
bool gLibraryLinux::load(const gString &lib)
{
    unload();
    m_libpath = lib;
    m_libhandle = dlopen(lib.asciiData(),RTLD_LAZY);
    return (m_libhandle != 0);
}
void gLibraryLinux::unload()
{
    if(m_libhandle)
    {
        dlclose(m_libhandle);
        m_libhandle = 0;
        m_libpath.clear();
    }

}
void *gLibraryLinux::resolve(const gString &funcname)
{
    if(m_libhandle)
    {
        return dlsym(m_libhandle,funcname.asciiData());
    }
}
bool gLibraryLinux::isLoaded() const
{
    return (m_libhandle != 0);
}
#endif
