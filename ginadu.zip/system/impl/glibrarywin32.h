#ifndef GLIBRARYWIN32_H
#define GLIBRARYWIN32_H
/**************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glibrarywin32.h
        Description: Implementation of class gLibraryWin32
***************************************************************************/
#include <system/glibrarysand.h>
#include <windows.h>
namespace gcf
{
class gLibraryWin32: public gLibrarySand
{
public:
    gLibraryWin32();
    virtual ~gLibraryWin32();
    virtual bool load(const gString &lib);
    virtual void unload();
    virtual void *resolve(const gString &funcname);
    virtual bool isLoaded() const;
protected:
    HMODULE m_libhandle;

};
}
#endif // GLIBRARYWIN32_H
