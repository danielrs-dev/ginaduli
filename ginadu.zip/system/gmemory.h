#ifndef GMEMORY_H
#define GMEMORY_H
#include <base/gcommon.h>

namespace gcf
{
class SHARED_GCF gMemory
{
public:
    gMemory();
    ~gMemory();

    static void *alloc(gu32 nsize);
    static void *alloc(gu32 block, gu32 nsize);
    static void *ralloc(void *ptr, gu32 nsize);
    static void *ralloc(void *ptr, gu32 block, gu32 nsize);
    static void dalloc(void *mem);


};
}
#endif // GMEMORY_H
