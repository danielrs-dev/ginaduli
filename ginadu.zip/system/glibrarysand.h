#ifndef GLIBRARYSAND_H
#define GLIBRARYSAND_H
/**************************************************************************
        GINA DULI C++ Framework
        Author: Daniel Rios
        File: glibrarysand.h
        Description: Implementation of class gLibrarySand
***************************************************************************/

#include <gstring/gstring.h>

namespace gcf
{
class gLibrarySand
{
public:
    gLibrarySand()
    {

    }
    virtual ~gLibrarySand()
    {

    }
    virtual bool load(const gString &lib) = 0;
    virtual void unload() = 0;
    virtual void *resolve(const gString &funcname) = 0;
    virtual bool isLoaded() const = 0;
    const gString &path() const
    {
        return m_libpath;
    }
protected:
    gString m_libpath;
};
}

#endif // GLIBRARYSAND_H
